import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
  },
});

export type Course = {
  id: string;
  slug: string;
  title: string;
  description: string;
  language: string;
  icon: string;
  color: string;
  difficulty_order: number;
};

export type LessonSection =
  | { type: 'text'; title: string; body: string }
  | { type: 'code'; title: string; code: string; output: string }
  | { type: 'tip'; body: string };

export type LessonContent = {
  sections: LessonSection[];
};

export type ChallengeTest =
  | { type: 'output_match'; expected: string }
  | { type: 'contains'; expected: string };

export type Challenge = {
  type: 'code_output';
  prompt: string;
  starter_code: string;
  solution: string;
  tests: ChallengeTest[];
  hints?: string[];
};

export type Lesson = {
  id: string;
  course_id: string;
  title: string;
  description: string;
  content: LessonContent;
  challenge: Challenge;
  xp_reward: number;
  order_index: number;
};

export type LessonProgress = {
  id: string;
  user_id: string;
  lesson_id: string;
  status: 'in_progress' | 'completed';
  xp_earned: number;
  completed_at: string | null;
  strength: number;
  last_reviewed_at: string | null;
  review_count: number;
  times_correct: number;
  times_incorrect: number;
};

export type PracticeSession = {
  id: string;
  user_id: string;
  lesson_id: string;
  correct: boolean;
  xp_earned: number;
  completed_at: string;
  created_at: string;
};

export type Achievement = {
  id: string;
  slug: string;
  title: string;
  description: string;
  icon: string;
  xp_bonus: number;
};

export type UserAchievement = {
  id: string;
  user_id: string;
  achievement_id: string;
  unlocked_at: string;
};

export type Profile = {
  id: string;
  username: string;
  total_xp: number;
  current_streak: number;
  longest_streak: number;
  last_activity_date: string | null;
  daily_goal: number;
  created_at: string;
};
