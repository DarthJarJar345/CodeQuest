// In-browser code execution engine for Python, JavaScript, HTML/CSS, and SQL
// Python is simulated with a lightweight interpreter that handles the subset
// of language features used in our lessons.

export type ExecResult = {
  output: string;
  error: string | null;
  preview?: string;
};

export function executeCode(code: string, language: string): ExecResult {
  const lang = language.toLowerCase().replace('/', '').replace(/\s/g, '');

  if (lang === 'javascript' || lang === 'js') {
    return executeJavaScript(code);
  }
  if (lang === 'python' || lang === 'py') {
    return executePython(code);
  }
  if (lang === 'htmlcss' || lang === 'html') {
    return executeHtmlCss(code);
  }
  if (lang === 'sql') {
    return executeSql(code);
  }
  return { output: '', error: `Unsupported language: ${language}` };
}

// ─── JavaScript ──────────────────────────────────────────────────────────

function executeJavaScript(code: string): ExecResult {
  let output = '';
  const captureLog = (...args: any[]) => {
    output += args.map(formatJsValue).join(' ') + '\n';
  };

  try {
    const fn = new Function('console', `"use strict";\n${code}`);
    fn({
      log: captureLog,
      error: captureLog,
      warn: captureLog,
      info: captureLog,
      dir: captureLog,
    });
    return { output: output.trimEnd(), error: null };
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    return { output: output.trimEnd(), error: msg };
  }
}

function formatJsValue(val: any): string {
  if (val === null) return 'null';
  if (val === undefined) return 'undefined';
  if (typeof val === 'string') return val;
  if (typeof val === 'object') {
    try {
      if (Array.isArray(val)) {
        return '[ ' + val.map((v) => formatJsValueInline(v)).join(', ') + ' ]';
      }
      return JSON.stringify(val);
    } catch {
      return String(val);
    }
  }
  return String(val);
}

function formatJsValueInline(val: any): string {
  if (typeof val === 'string') return `'${val}'`;
  return formatJsValue(val);
}

// ─── Python ──────────────────────────────────────────────────────────────
// A line-based interpreter that supports: variable assignment, arithmetic,
// string operations, print/len/sum/range/str/int/float/type, if/elif/else,
// for loops (range and iterables), while loops, function definitions with
// return, list/dict literals, list indexing, dict access, and method calls
// on strings and lists.

type PyValue = number | string | boolean | null | PyValue[] | { [key: string]: PyValue } | PyFunc;

type PyFunc = {
  __func: true;
  params: string[];
  body: string[];
  closure: PyScope;
};

type PyScope = Record<string, PyValue>;

function executePython(code: string): ExecResult {
  const interp = new PythonInterpreter();
  return interp.run(code);
}

class PythonInterpreter {
  output = '';
  error: string | null = null;
  globals: PyScope = {};

  run(code: string): ExecResult {
    try {
      const lines = code.split('\n');
      this.execBlock(lines, 0, lines.length, 0, this.globals);
    } catch (err) {
      this.error = err instanceof Error ? err.message : String(err);
    }
    return { output: this.output.trimEnd(), error: this.error };
  }

  // Execute lines[start..end) that are indented at >= minIndent.
  // Returns the index of the first line NOT consumed (for if/for/while bodies).
  execBlock(lines: string[], start: number, end: number, minIndent: number, scope: PyScope): number {
    let i = start;
    while (i < end) {
      const line = lines[i];
      if (line.trim() === '' || line.trim().startsWith('#')) {
        i++;
        continue;
      }

      const indent = getIndent(line);
      if (indent < minIndent) break;

      const trimmed = line.trim();

      // Function definition
      if (trimmed.startsWith('def ')) {
        i = this.parseDef(lines, i, end, indent, scope);
        continue;
      }

      // if / elif / else
      if (trimmed.startsWith('if ') || trimmed === 'else:' || trimmed.startsWith('elif ')) {
        i = this.parseIf(lines, i, end, indent, scope);
        continue;
      }

      // for loop
      if (trimmed.startsWith('for ')) {
        i = this.parseFor(lines, i, end, indent, scope);
        continue;
      }

      // while loop
      if (trimmed.startsWith('while ')) {
        i = this.parseWhile(lines, i, end, indent, scope);
        continue;
      }

      // Regular statement
      this.execStatement(trimmed, scope);
      i++;
    }
    return i;
  }

  // Find the body of a block (indented lines after a colon line)
  private findBody(lines: string[], headerIdx: number, end: number, headerIndent: number): { bodyStart: number; bodyEnd: number } {
    let bi = headerIdx + 1;
    // Skip blank lines
    while (bi < end && lines[bi].trim() === '') bi++;
    const bodyIndent = bi < end ? getIndent(lines[bi]) : headerIndent + 4;
    if (bodyIndent <= headerIndent) {
      return { bodyStart: headerIdx + 1, bodyEnd: headerIdx + 1 };
    }
    let be = bi;
    while (be < end && (lines[be].trim() === '' || getIndent(lines[be]) >= bodyIndent)) {
      be++;
    }
    return { bodyStart: bi, bodyEnd: be };
  }

  parseDef(lines: string[], idx: number, end: number, indent: number, scope: PyScope): number {
    const trimmed = lines[idx].trim();
    const m = trimmed.match(/^def\s+(\w+)\s*\((.*)\):$/);
    if (!m) throw new Error(`Syntax error in function definition: ${trimmed}`);
    const [, name, paramsStr] = m;
    const params = paramsStr.split(',').map((p) => p.trim()).filter(Boolean);
    const { bodyStart, bodyEnd } = this.findBody(lines, idx, end, indent);
    scope[name] = {
      __func: true,
      params,
      body: lines.slice(bodyStart, bodyEnd),
      closure: { ...scope },
    } as PyFunc;
    return bodyEnd;
  }

  parseIf(lines: string[], idx: number, end: number, indent: number, scope: PyScope): number {
    let i = idx;
    let executed = false;

    while (i < end) {
      const line = lines[i];
      const lineIndent = getIndent(line);
      if (lineIndent < indent) break;
      if (lineIndent > indent) { i++; continue; }

      const trimmed = line.trim();
      if (trimmed.startsWith('if ')) {
        const cond = trimmed.slice(3, -1); // remove "if " and ":"
        if (!executed && this.evalExpr(cond, scope)) {
          executed = true;
          const { bodyStart, bodyEnd } = this.findBody(lines, i, end, indent);
          this.execBlock(lines, bodyStart, bodyEnd, indent + 1, scope);
          i = bodyEnd;
        } else {
          const { bodyEnd } = this.findBody(lines, i, end, indent);
          i = bodyEnd;
        }
      } else if (trimmed.startsWith('elif ')) {
        if (lineIndent !== indent) break;
        const cond = trimmed.slice(5, -1);
        if (!executed && this.evalExpr(cond, scope)) {
          executed = true;
          const { bodyStart, bodyEnd } = this.findBody(lines, i, end, indent);
          this.execBlock(lines, bodyStart, bodyEnd, indent + 1, scope);
          i = bodyEnd;
        } else {
          const { bodyEnd } = this.findBody(lines, i, end, indent);
          i = bodyEnd;
        }
      } else if (trimmed === 'else:') {
        if (lineIndent !== indent) break;
        if (!executed) {
          const { bodyStart, bodyEnd } = this.findBody(lines, i, end, indent);
          this.execBlock(lines, bodyStart, bodyEnd, indent + 1, scope);
          i = bodyEnd;
        } else {
          const { bodyEnd } = this.findBody(lines, i, end, indent);
          i = bodyEnd;
        }
      } else {
        break;
      }
    }
    return i;
  }

  parseFor(lines: string[], idx: number, end: number, indent: number, scope: PyScope): number {
    const trimmed = lines[idx].trim();
    // for x in range(...):
    const rangeMatch = trimmed.match(/^for\s+(\w+)\s+in\s+range\((.*)\):$/);
    if (rangeMatch) {
      const [, varName, argsStr] = rangeMatch;
      const rangeVals = this.evalArgs(argsStr, scope);
      let start = 0, stop = 0, step = 1;
      if (rangeVals.length === 1) stop = Number(rangeVals[0]);
      else if (rangeVals.length === 2) { start = Number(rangeVals[0]); stop = Number(rangeVals[1]); }
      else if (rangeVals.length === 3) { start = Number(rangeVals[0]); stop = Number(rangeVals[1]); step = Number(rangeVals[2]); }

      const { bodyStart, bodyEnd } = this.findBody(lines, idx, end, indent);
      const bodyLines = lines.slice(bodyStart, bodyEnd);

      for (let v = start; step > 0 ? v < stop : v > stop; v += step) {
        scope[varName] = v;
        this.execBlock(bodyLines, 0, bodyLines.length, 0, scope);
      }
      return bodyEnd;
    }

    // for x in iterable:
    const iterMatch = trimmed.match(/^for\s+(\w+)\s+in\s+(.+):$/);
    if (iterMatch) {
      const [, varName, iterExpr] = iterMatch;
      const iterable = this.evalExpr(iterExpr, scope);
      const { bodyStart, bodyEnd } = this.findBody(lines, idx, end, indent);
      const bodyLines = lines.slice(bodyStart, bodyEnd);

      if (Array.isArray(iterable)) {
        for (const item of iterable) {
          scope[varName] = item;
          this.execBlock(bodyLines, 0, bodyLines.length, 0, scope);
        }
      } else if (typeof iterable === 'string') {
        for (const ch of iterable) {
          scope[varName] = ch;
          this.execBlock(bodyLines, 0, bodyLines.length, 0, scope);
        }
      }
      return bodyEnd;
    }

    throw new Error(`Syntax error in for loop: ${trimmed}`);
  }

  parseWhile(lines: string[], idx: number, end: number, indent: number, scope: PyScope): number {
    const trimmed = lines[idx].trim();
    const m = trimmed.match(/^while\s+(.+):$/);
    if (!m) throw new Error(`Syntax error in while loop: ${trimmed}`);
    const [, cond] = m;
    const { bodyStart, bodyEnd } = this.findBody(lines, idx, end, indent);
    const bodyLines = lines.slice(bodyStart, bodyEnd);

    let iterations = 0;
    while (this.evalExpr(cond, scope) && iterations < 10000) {
      this.execBlock(bodyLines, 0, bodyLines.length, 0, scope);
      iterations++;
    }
    return bodyEnd;
  }

  execStatement(trimmed: string, scope: PyScope): void {
    // return (inside function body — handled by callFunc)
    if (trimmed.startsWith('return ')) return;

    // Augmented assignment: x += 1
    const augMatch = trimmed.match(/^(\w+)\s*(\+=|-=|\*=|\/=)\s*(.+)$/);
    if (augMatch) {
      const [, name, op, valExpr] = augMatch;
      const cur = Number(scope[name] ?? 0);
      const val = Number(this.evalExpr(valExpr, scope));
      if (op === '+=') scope[name] = cur + val;
      else if (op === '-=') scope[name] = cur - val;
      else if (op === '*=') scope[name] = cur * val;
      else if (op === '/=') scope[name] = cur / val;
      return;
    }

    // Assignment: x = value
    const assignMatch = trimmed.match(/^(\w+)\s*=\s*(.+)$/);
    if (assignMatch && !trimmed.includes('==')) {
      const [, name, valExpr] = assignMatch;
      scope[name] = this.evalExpr(valExpr, scope);
      return;
    }

    // Expression statement (print, function call, etc.)
    this.evalExpr(trimmed, scope);
  }

  evalArgs(argsStr: string, scope: PyScope): PyValue[] {
    if (!argsStr.trim()) return [];
    return splitArgs(argsStr).map((a) => this.evalExpr(a.trim(), scope));
  }

  evalExpr(expr: string, scope: PyScope): PyValue {
    expr = expr.trim();
    if (!expr) return null;

    // Parenthesized expression
    if (expr.startsWith('(') && expr.endsWith(')')) {
      return this.evalExpr(expr.slice(1, -1), scope);
    }

    // String literal (double or single quotes)
    if (/^"([^"\\]|\\.)*"$/.test(expr) || /^'([^'\\]|\\.)*'$/.test(expr)) {
      return parseStringLiteral(expr);
    }

    // F-string: f"Hello {name}"
    if (/^f["']/.test(expr)) {
      const inner = expr.slice(2, -1);
      return inner.replace(/\{([^}]+)\}/g, (_, e) => {
        const val = this.evalExpr(e.trim(), scope);
        return this.formatPy(val);
      });
    }

    // Number
    if (/^-?\d+\.?\d*$/.test(expr)) return Number(expr);

    // Boolean / None
    if (expr === 'True') return true;
    if (expr === 'False') return false;
    if (expr === 'None') return null;

    // List literal: [1, 2, 3]
    if (expr.startsWith('[') && expr.endsWith(']')) {
      const inner = expr.slice(1, -1).trim();
      if (!inner) return [];
      return splitArgs(inner).map((a) => this.evalExpr(a.trim(), scope));
    }

    // Dict literal: {"key": value}
    if (expr.startsWith('{') && expr.endsWith('}')) {
      const inner = expr.slice(1, -1).trim();
      if (!inner) return {};
      const result: { [key: string]: PyValue } = {};
      for (const pair of splitArgs(inner)) {
        const colonIdx = pair.indexOf(':');
        if (colonIdx === -1) continue;
        const key = this.evalExpr(pair.slice(0, colonIdx).trim(), scope);
        const val = this.evalExpr(pair.slice(colonIdx + 1).trim(), scope);
        result[String(key)] = val;
      }
      return result;
    }

    // Indexing: var[expr]
    const indexMatch = expr.match(/^(\w+)\[(.+)\]$/);
    if (indexMatch) {
      const [, name, idxExpr] = indexMatch;
      const val = scope[name];
      const idx = this.evalExpr(idxExpr, scope);
      if (Array.isArray(val)) {
        const i = Number(idx);
        return val[i < 0 ? i + val.length : i];
      }
      if (typeof val === 'string') {
        const i = Number(idx);
        return val[i < 0 ? i + val.length : i];
      }
      if (typeof val === 'object' && val !== null && !Array.isArray(val)) {
        return (val as { [key: string]: PyValue })[String(idx)];
      }
      return null;
    }

    // Method call: var.method(args) or var.method()
    const methodMatch = expr.match(/^(\w+)\.(\w+)\((.*)\)$/);
    if (methodMatch) {
      const [, varName, methodName, argsStr] = methodMatch;
      const val = scope[varName];
      const args = this.evalArgs(argsStr, scope);
      return this.callMethod(val, methodName, args);
    }

    // Function call: func(args)
    const funcMatch = expr.match(/^(\w+)\((.*)\)$/);
    if (funcMatch) {
      const [, name, argsStr] = funcMatch;
      const args = this.evalArgs(argsStr, scope);
      return this.callFunc(name, args, scope);
    }

    // Variable reference
    if (/^\w+$/.test(expr)) {
      if (expr in scope) return scope[expr];
      throw new Error(`NameError: name '${expr}' is not defined`);
    }

    // Comparison and boolean expressions
    const boolResult = this.evalBool(expr, scope);
    if (boolResult !== undefined) return boolResult;

    // Arithmetic expression
    return this.evalArithmetic(expr, scope);
  }

  evalBool(expr: string, scope: PyScope): boolean | undefined {
    // and / or
    const orParts = splitOnOperator(expr, ' or ');
    if (orParts.length > 1) {
      for (const part of orParts) {
        if (this.evalExpr(part.trim(), scope)) return true;
      }
      return false;
    }

    const andParts = splitOnOperator(expr, ' and ');
    if (andParts.length > 1) {
      for (const part of andParts) {
        if (!this.evalExpr(part.trim(), scope)) return false;
      }
      return true;
    }

    // not
    if (expr.startsWith('not ')) {
      return !this.evalExpr(expr.slice(4).trim(), scope);
    }

    // Comparisons: ==, !=, >=, <=, >, <
    const compMatch = expr.match(/^(.+?)\s*(==|!=|>=|<=|>|<)\s*(.+)$/);
    if (compMatch) {
      const [, left, op, right] = compMatch;
      const l = this.evalExpr(left.trim(), scope);
      const r = this.evalExpr(right.trim(), scope);
      switch (op) {
        case '==': return l === r;
        case '!=': return l !== r;
        case '>=': return Number(l) >= Number(r);
        case '<=': return Number(l) <= Number(r);
        case '>': return Number(l) > Number(r);
        case '<': return Number(l) < Number(r);
      }
    }

    return undefined;
  }

  evalArithmetic(expr: string, scope: PyScope): PyValue {
    // Replace Python tokens with JS equivalents
    let jsExpr = expr
      .replace(/\bTrue\b/g, 'true')
      .replace(/\bFalse\b/g, 'false')
      .replace(/\bNone\b/g, 'null')
      .replace(/\band\b/g, '&&')
      .replace(/\bor\b/g, '||')
      .replace(/\bnot\b/g, '!');

    // Replace string literals with placeholders to avoid mangling
    const strings: string[] = [];
    jsExpr = jsExpr.replace(/(["'])(?:(?=(\\?))\2.)*?\1/g, (s) => {
      strings.push(s);
      return `__STR${strings.length - 1}__`;
    });

    // Replace variable references
    jsExpr = jsExpr.replace(/\b([a-zA-Z_]\w*)\b/g, (match) => {
      if (['true', 'false', 'null', 'undefined', 'NaN', 'Infinity'].includes(match)) return match;
      if (match.startsWith('__STR') && match.endsWith('__')) return match;
      if (match in scope) {
        const v = scope[match];
        if (typeof v === 'string') return JSON.stringify(v);
        if (typeof v === 'boolean') return String(v);
        if (v === null) return 'null';
        return String(v);
      }
      return match;
    });

    // Restore strings
    jsExpr = jsExpr.replace(/__STR(\d+)__/g, (_, i) => strings[Number(i)]);

    try {
      const result = new Function(`"use strict"; return (${jsExpr});`)();
      return result as PyValue;
    } catch {
      throw new Error(`Could not evaluate: ${expr}`);
    }
  }

  callFunc(name: string, args: PyValue[], scope: PyScope): PyValue {
    // Built-in functions
    switch (name) {
      case 'print': {
        this.output += args.map((a) => this.formatPy(a)).join(' ') + '\n';
        return null;
      }
      case 'len': {
        const v = args[0];
        if (Array.isArray(v)) return v.length;
        if (typeof v === 'string') return v.length;
        if (typeof v === 'object' && v !== null) return Object.keys(v).length;
        throw new Error('len() requires a sequence or collection');
      }
      case 'sum': {
        const v = args[0];
        if (Array.isArray(v)) return (v as number[]).reduce((a, b) => a + b, 0);
        throw new Error('sum() requires a list');
      }
      case 'range': {
        let start = 0, stop = 0, step = 1;
        if (args.length === 1) stop = Number(args[0]);
        else if (args.length === 2) { start = Number(args[0]); stop = Number(args[1]); }
        else if (args.length === 3) { start = Number(args[0]); stop = Number(args[1]); step = Number(args[2]); }
        const result: number[] = [];
        for (let v = start; step > 0 ? v < stop : v > stop; v += step) result.push(v);
        return result;
      }
      case 'str': return this.formatPy(args[0]);
      case 'int': return parseInt(String(args[0]), 10);
      case 'float': return parseFloat(String(args[0]));
      case 'type': {
        const v = args[0];
        if (Array.isArray(v)) return 'list';
        if (typeof v === 'string') return 'str';
        if (typeof v === 'number') return Number.isInteger(v) ? 'int' : 'float';
        if (typeof v === 'boolean') return 'bool';
        if (v === null) return 'NoneType';
        return 'dict';
      }
      case 'abs': return Math.abs(Number(args[0]));
      case 'max': return Math.max(...args.map(Number));
      case 'min': return Math.min(...args.map(Number));
      case 'round': return Math.round(Number(args[0]));
      case 'input': return ''; // no stdin
    }

    // User-defined function
    const fn = scope[name];
    if (fn && typeof fn === 'object' && (fn as PyFunc).__func) {
      return this.callUserFunc(fn as PyFunc, args);
    }

    throw new Error(`NameError: name '${name}' is not defined`);
  }

  callUserFunc(fn: PyFunc, args: PyValue[]): PyValue {
    const localScope: PyScope = { ...fn.closure };
    fn.params.forEach((p, idx) => {
      localScope[p] = args[idx] ?? null;
    });

    for (const line of fn.body) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith('#')) continue;

      if (trimmed.startsWith('return ')) {
        return this.evalExpr(trimmed.slice(7), localScope);
      }
      if (trimmed === 'return') return null;

      // Handle nested if/for/while inside functions
      const indent = getIndent(line);
      if (trimmed.startsWith('if ') || trimmed === 'else:' || trimmed.startsWith('elif ')) {
        const idx = fn.body.indexOf(line);
        this.parseIf(fn.body, idx, fn.body.length, indent, localScope);
        continue;
      }
      if (trimmed.startsWith('for ')) {
        const idx = fn.body.indexOf(line);
        this.parseFor(fn.body, idx, fn.body.length, indent, localScope);
        continue;
      }
      if (trimmed.startsWith('while ')) {
        const idx = fn.body.indexOf(line);
        this.parseWhile(fn.body, idx, fn.body.length, indent, localScope);
        continue;
      }

      this.execStatement(trimmed, localScope);
    }
    return null;
  }

  callMethod(val: PyValue, method: string, args: PyValue[]): PyValue {
    if (typeof val === 'string') {
      switch (method) {
        case 'upper': return val.toUpperCase();
        case 'lower': return val.toLowerCase();
        case 'strip': return val.trim();
        case 'lstrip': return val.replace(/^\s+/, '');
        case 'rstrip': return val.replace(/\s+$/, '');
        case 'split': return args[0] !== undefined ? val.split(String(args[0])) : val.split(/\s+/);
        case 'replace': return val.split(String(args[0])).join(String(args[1]));
        case 'find': return val.indexOf(String(args[0]));
        case 'count': {
          const sub = String(args[0]);
          if (!sub) return 0;
          let count = 0, pos = 0;
          while ((pos = val.indexOf(sub, pos)) !== -1) { count++; pos += sub.length; }
          return count;
        }
        case 'startswith': return val.startsWith(String(args[0]));
        case 'endswith': return val.endsWith(String(args[0]));
        case 'format': {
          let result = val;
          args.forEach((a, i) => {
            result = result.replace(/\{\}/, this.formatPy(a));
            void i;
          });
          return result;
        }
        case 'capitalize': return val.charAt(0).toUpperCase() + val.slice(1).toLowerCase();
        case 'title': return val.replace(/\b\w/g, (c) => c.toUpperCase());
      }
    }
    if (Array.isArray(val)) {
      switch (method) {
        case 'append': val.push(args[0]); return null;
        case 'remove': {
          const idx = val.indexOf(args[0]);
          if (idx !== -1) val.splice(idx, 1);
          return null;
        }
        case 'pop': return val.pop() ?? null;
        case 'sort': val.sort((a, b) => Number(a) - Number(b)); return null;
        case 'reverse': val.reverse(); return null;
        case 'count': return val.filter((x) => x === args[0]).length;
        case 'index': return val.indexOf(args[0]);
        case 'extend': (args[0] as PyValue[]).forEach((x) => val.push(x)); return null;
        case 'insert': val.splice(Number(args[0]), 0, args[1]); return null;
        case 'join': return val.join(String(args[0]));
      }
    }
    if (typeof val === 'object' && val !== null && !Array.isArray(val)) {
      const dict = val as { [key: string]: PyValue };
      switch (method) {
        case 'keys': return Object.keys(dict);
        case 'values': return Object.values(dict);
        case 'get': return dict[String(args[0])] ?? args[1] ?? null;
        case 'pop': {
          const k = String(args[0]);
          const v = dict[k];
          delete dict[k];
          return v;
        }
      }
    }
    throw new Error(`AttributeError: '${this.typeName(val)}' object has no attribute '${method}'`);
  }

  formatPy(val: PyValue): string {
    if (val === true) return 'True';
    if (val === false) return 'False';
    if (val === null) return 'None';
    if (Array.isArray(val)) return '[' + val.map((v) => this.formatPyInline(v)).join(', ') + ']';
    if (typeof val === 'object' && val !== null) {
      const entries = Object.entries(val).map(([k, v]) => `'${k}': ${this.formatPyInline(v)}`);
      return '{' + entries.join(', ') + '}';
    }
    return String(val);
  }

  formatPyInline(val: PyValue): string {
    if (typeof val === 'string') return `'${val}'`;
    return this.formatPy(val);
  }

  typeName(val: PyValue): string {
    if (Array.isArray(val)) return 'list';
    if (typeof val === 'string') return 'str';
    if (typeof val === 'number') return 'int';
    if (typeof val === 'boolean') return 'bool';
    if (val === null) return 'NoneType';
    return 'dict';
  }
}

// ─── HTML/CSS ────────────────────────────────────────────────────────────

function executeHtmlCss(code: string): ExecResult {
  // For HTML/CSS, we render a preview and validate structure
  const hasTag = /<\w+/.test(code);
  if (!hasTag) {
    return { output: '', error: 'No HTML tags found. Make sure to write valid HTML elements.' };
  }
  return {
    output: 'HTML rendered successfully!',
    error: null,
    preview: code,
  };
}

// ─── SQL ──────────────────────────────────────────────────────────────────

function executeSql(code: string): ExecResult {
  const trimmed = code.trim().replace(/;$/, '');
  if (!trimmed) {
    return { output: '', error: 'Empty query. Write a SQL statement.' };
  }

  // Basic SQL validation
  const upper = trimmed.toUpperCase();
  const validStarts = ['SELECT', 'INSERT', 'UPDATE', 'DELETE', 'CREATE', 'DROP', 'ALTER'];
  const startsValid = validStarts.some((s) => upper.startsWith(s));

  if (!startsValid) {
    return { output: '', error: 'Invalid SQL. Start with SELECT, INSERT, UPDATE, or DELETE.' };
  }

  return { output: 'Query executed successfully!', error: null };
}

// ─── Helpers ──────────────────────────────────────────────────────────────

function getIndent(line: string): number {
  const match = line.match(/^(\s*)/);
  if (!match) return 0;
  const ws = match[1];
  // Count tabs as 4, spaces as 1
  return ws.split('').reduce((acc, c) => acc + (c === '\t' ? 4 : 1), 0);
}

function parseStringLiteral(expr: string): string {
  // Handle escape sequences
  const quote = expr[0];
  const inner = expr.slice(1, -1);
  return inner
    .replace(/\\n/g, '\n')
    .replace(/\\t/g, '\t')
    .replace(new RegExp(`\\\\${quote}`, 'g'), quote)
    .replace(/\\\\/g, '\\');
}

// Split arguments respecting nested parens, brackets, and quotes
function splitArgs(str: string): string[] {
  const result: string[] = [];
  let depth = 0;
  let current = '';
  let inString = false;
  let stringChar = '';

  for (let i = 0; i < str.length; i++) {
    const ch = str[i];
    if (inString) {
      current += ch;
      if (ch === stringChar && str[i - 1] !== '\\') inString = false;
      continue;
    }
    if (ch === '"' || ch === "'") {
      inString = true;
      stringChar = ch;
      current += ch;
      continue;
    }
    if (ch === '(' || ch === '[' || ch === '{') depth++;
    if (ch === ')' || ch === ']' || ch === '}') depth--;
    if (ch === ',' && depth === 0) {
      result.push(current.trim());
      current = '';
      continue;
    }
    current += ch;
  }
  if (current.trim()) result.push(current.trim());
  return result;
}

// Split on a keyword operator (like " or ", " and ") respecting strings
function splitOnOperator(str: string, op: string): string[] {
  const parts: string[] = [];
  let current = '';
  let inString = false;
  let stringChar = '';
  const opLower = op.toLowerCase();

  for (let i = 0; i < str.length; i++) {
    const ch = str[i];
    if (inString) {
      current += ch;
      if (ch === stringChar && str[i - 1] !== '\\') inString = false;
      continue;
    }
    if (ch === '"' || ch === "'") {
      inString = true;
      stringChar = ch;
      current += ch;
      continue;
    }
    const remaining = str.slice(i).toLowerCase();
    if (remaining.startsWith(opLower)) {
      parts.push(current.trim());
      current = '';
      i += op.length - 1;
      continue;
    }
    current += ch;
  }
  if (current.trim()) parts.push(current.trim());
  return parts;
}
