import { supabase, Course, Lesson, LessonProgress, PracticeSession, Achievement, UserAchievement } from './supabase';

// ─── Strength decay (spaced-repetition) ────────────────────────────────────
// Strength starts at 1.0 when a lesson is completed or reviewed. It decays
// over time based on how long ago the user last touched the lesson. The
// curve is gentle at first and steepens, mirroring Duolingo's "skill
// strength" decay. Capped at 0 so strength never goes negative.

const HALF_LIFE_DAYS = 5; // strength halves roughly every 5 days

export function computeStrength(lastTouchedAt: string | null): number {
  if (!lastTouchedAt) return 0;
  const now = Date.now();
  const then = new Date(lastTouchedAt).getTime();
  const daysSince = Math.max(0, (now - then) / (1000 * 60 * 60 * 24));
  const strength = Math.pow(0.5, daysSince / HALF_LIFE_DAYS);
  return Math.max(0, Math.min(1, strength));
}

export function getEffectiveStrength(progress: LessonProgress): number {
  const lastTouched = progress.last_reviewed_at ?? progress.completed_at;
  return computeStrength(lastTouched);
}

export function strengthLabel(strength: number): 'Fresh' | 'Solid' | 'Fading' | 'Rusty' | 'New' {
  if (strength >= 0.8) return 'Fresh';
  if (strength >= 0.5) return 'Solid';
  if (strength >= 0.25) return 'Fading';
  if (strength > 0) return 'Rusty';
  return 'New';
}

export function strengthColor(strength: number): string {
  if (strength >= 0.8) return '#22c55e'; // success-500
  if (strength >= 0.5) return '#3399ff'; // brand-500
  if (strength >= 0.25) return '#f59e0b'; // accent-500
  return '#ef4444'; // error-500
}

// ─── Daily goal helpers ────────────────────────────────────────────────────

export function todayDateKey(): string {
  return new Date().toISOString().split('T')[0];
}

export function computeTodayXp(
  progress: LessonProgress[],
  sessions: PracticeSession[]
): number {
  const today = todayDateKey();
  const lessonXp = progress
    .filter((p) => p.status === 'completed' && p.completed_at?.startsWith(today))
    .reduce((sum, p) => sum + (p.xp_earned ?? 0), 0);
  const practiceXp = sessions
    .filter((s) => s.completed_at?.startsWith(today))
    .reduce((sum, s) => sum + (s.xp_earned ?? 0), 0);
  return lessonXp + practiceXp;
}

export async function updateDailyGoal(userId: string, goal: number): Promise<void> {
  const { error } = await supabase
    .from('profiles')
    .update({ daily_goal: goal })
    .eq('id', userId);
  if (error) throw error;
}

export async function fetchCourses(): Promise<Course[]> {
  const { data, error } = await supabase
    .from('courses')
    .select('*')
    .order('difficulty_order', { ascending: true });
  if (error) throw error;
  return data as Course[];
}

export async function fetchLessonsByCourse(courseId: string): Promise<Lesson[]> {
  const { data, error } = await supabase
    .from('lessons')
    .select('*')
    .eq('course_id', courseId)
    .order('order_index', { ascending: true });
  if (error) throw error;
  return data as Lesson[];
}

export async function fetchAllLessons(): Promise<Lesson[]> {
  const { data, error } = await supabase
    .from('lessons')
    .select('*')
    .order('order_index', { ascending: true });
  if (error) throw error;
  return data as Lesson[];
}

export async function fetchUserProgress(userId: string): Promise<LessonProgress[]> {
  const { data, error } = await supabase
    .from('lesson_progress')
    .select('*')
    .eq('user_id', userId);
  if (error) throw error;
  return data as LessonProgress[];
}

export async function fetchAchievements(): Promise<Achievement[]> {
  const { data, error } = await supabase
    .from('achievements')
    .select('*')
    .order('xp_bonus', { ascending: true });
  if (error) throw error;
  return data as Achievement[];
}

export async function fetchUserAchievements(userId: string): Promise<UserAchievement[]> {
  const { data, error } = await supabase
    .from('user_achievements')
    .select('*')
    .eq('user_id', userId);
  if (error) throw error;
  return data as UserAchievement[];
}

export type LessonCompletionResult = {
  xpAwarded: number;
  newlyUnlocked: string[];
  alreadyCompleted: boolean;
};

export async function completeLesson(
  userId: string,
  lessonId: string,
  xpReward: number
): Promise<LessonCompletionResult> {
  // Check if already completed
  const { data: existing } = await supabase
    .from('lesson_progress')
    .select('*')
    .eq('user_id', userId)
    .eq('lesson_id', lessonId)
    .maybeSingle();

  const alreadyCompleted = existing?.status === 'completed';

  // Only award XP if not already completed
  const xpAwarded = alreadyCompleted ? 0 : xpReward;

  const nowIso = new Date().toISOString();

  if (alreadyCompleted) {
    // Re-completing a lesson acts as a review: refresh strength, bump review
    // counters, and update last_reviewed_at — but don't overwrite completed_at
    // (the original completion date is meaningful for history).
    const prev = existing as LessonProgress;
    await supabase
      .from('lesson_progress')
      .update({
        strength: 1.0,
        last_reviewed_at: nowIso,
        review_count: (prev.review_count ?? 0) + 1,
        times_correct: (prev.times_correct ?? 0) + 1,
      })
      .eq('user_id', userId)
      .eq('lesson_id', lessonId);
  } else {
    // First-time completion
    const { error: upsertError } = await supabase
      .from('lesson_progress')
      .upsert(
        {
          user_id: userId,
          lesson_id: lessonId,
          status: 'completed',
          xp_earned: xpReward,
          completed_at: nowIso,
          strength: 1.0,
        },
        { onConflict: 'user_id,lesson_id' }
      );
    if (upsertError) throw upsertError;
  }

  // Update profile XP and streak only if XP was awarded
  if (xpAwarded > 0) {
    const { data: profile } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .maybeSingle();

    if (profile) {
      const today = new Date().toISOString().split('T')[0];
      const lastActivity = profile.last_activity_date;
      let newStreak = profile.current_streak;

      if (lastActivity !== today) {
        if (lastActivity) {
          const yesterday = new Date();
          yesterday.setDate(yesterday.getDate() - 1);
          const yesterdayStr = yesterday.toISOString().split('T')[0];
          if (lastActivity === yesterdayStr) {
            newStreak = profile.current_streak + 1;
          } else {
            newStreak = 1;
          }
        } else {
          newStreak = 1;
        }
      }

      const newTotalXp = profile.total_xp + xpAwarded;
      const newLongestStreak = Math.max(profile.longest_streak, newStreak);

      await supabase
        .from('profiles')
        .update({
          total_xp: newTotalXp,
          current_streak: newStreak,
          longest_streak: newLongestStreak,
          last_activity_date: today,
        })
        .eq('id', userId);
    }
  }

  // Check achievements
  const [allProgress, allLessons, allCourses] = await Promise.all([
    fetchUserProgress(userId),
    fetchAllLessons(),
    fetchCourses(),
  ]);

  const completedLessonIds = allProgress
    .filter((p) => p.status === 'completed')
    .map((p) => p.lesson_id);

  const completedCourseIds = new Set(
    allLessons
      .filter((l) => completedLessonIds.includes(l.id))
      .map((l) => l.course_id)
  );

  const now = new Date();
  const hourOfDay = now.getHours();

  const lessonsCompletedToday = allProgress.filter((p) => {
    if (p.status !== 'completed' || !p.completed_at) return false;
    const completedDate = new Date(p.completed_at).toISOString().split('T')[0];
    const today = now.toISOString().split('T')[0];
    return completedDate === today;
  }).length;

  // Get updated profile for accurate XP/streak
  const { data: updatedProfile } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', userId)
    .maybeSingle();

  const totalXp = updatedProfile?.total_xp ?? 0;
  const currentStreak = updatedProfile?.current_streak ?? 0;

  // Check for course completion achievement
  for (const course of allCourses) {
    const courseLessons = allLessons.filter((l) => l.course_id === course.id);
    const courseCompleted = courseLessons.every((l) => completedLessonIds.includes(l.id));
    if (courseCompleted && courseLessons.length > 0) {
      await tryUnlockAchievement(userId, 'course_complete');
    }
  }

  const newlyUnlocked = await checkAndUnlockAchievements(userId, {
    totalXp,
    currentStreak,
    completedLessonIds,
    coursesWithCompletions: completedCourseIds.size,
    lessonsCompletedToday,
    hourOfDay,
  });

  return { xpAwarded, newlyUnlocked, alreadyCompleted };
}

async function tryUnlockAchievement(userId: string, slug: string): Promise<void> {
  const { data: achievement } = await supabase
    .from('achievements')
    .select('id')
    .eq('slug', slug)
    .maybeSingle();

  if (achievement) {
    await supabase
      .from('user_achievements')
      .insert({ user_id: userId, achievement_id: achievement.id })
      .then(({ error }) => {
        if (error && !error.message.includes('duplicate')) {
          throw error;
        }
      });
  }
}

async function checkAndUnlockAchievements(
  userId: string,
  context: {
    totalXp: number;
    currentStreak: number;
    completedLessonIds: string[];
    coursesWithCompletions: number;
    lessonsCompletedToday: number;
    hourOfDay: number;
  }
): Promise<string[]> {
  const allAchievements = await fetchAchievements();
  const userAchievements = await fetchUserAchievements(userId);
  const unlockedSlugs = new Set(
    userAchievements.map((ua) => allAchievements.find((a) => a.id === ua.achievement_id)?.slug).filter(Boolean) as string[]
  );

  const newlyUnlocked: string[] = [];

  const check = (slug: string, condition: boolean) => {
    if (condition && !unlockedSlugs.has(slug)) {
      newlyUnlocked.push(slug);
    }
  };

  check('first_lesson', context.completedLessonIds.length >= 1);
  check('streak_3', context.currentStreak >= 3);
  check('streak_7', context.currentStreak >= 7);
  check('streak_30', context.currentStreak >= 30);
  check('xp_100', context.totalXp >= 100);
  check('xp_500', context.totalXp >= 500);
  check('xp_1000', context.totalXp >= 1000);
  check('polyglot', context.coursesWithCompletions >= 3);
  check('night_owl', context.hourOfDay >= 22);
  check('early_bird', context.hourOfDay < 7);
  check('speed_demon', context.lessonsCompletedToday >= 5);

  for (const slug of newlyUnlocked) {
    const achievement = allAchievements.find((a) => a.slug === slug);
    if (achievement) {
      const { error } = await supabase
        .from('user_achievements')
        .insert({ user_id: userId, achievement_id: achievement.id });
      if (error && !error.message.includes('duplicate')) {
        console.error('Failed to unlock achievement:', error);
      }
    }
  }

  return newlyUnlocked;
}

// ─── Practice / Reviews ────────────────────────────────────────────────────

export type ReviewCandidate = {
  lesson: Lesson;
  course: Course;
  progress: LessonProgress;
  strength: number;
};

export async function fetchPracticeSessions(userId: string): Promise<PracticeSession[]> {
  const { data, error } = await supabase
    .from('practice_sessions')
    .select('*')
    .eq('user_id', userId)
    .order('completed_at', { ascending: false });
  if (error) throw error;
  return data as PracticeSession[];
}

export async function fetchReviewCandidates(
  courses: Course[],
  lessons: Lesson[],
  progress: LessonProgress[]
): Promise<ReviewCandidate[]> {
  const completed = progress.filter((p) => p.status === 'completed');
  const lessonById = new Map(lessons.map((l) => [l.id, l]));
  const courseById = new Map(courses.map((c) => [c.id, c]));

  const candidates: ReviewCandidate[] = [];
  for (const p of completed) {
    const lesson = lessonById.get(p.lesson_id);
    const course = lesson ? courseById.get(lesson.course_id) : undefined;
    if (!lesson || !course) continue;
    const strength = getEffectiveStrength(p);
    candidates.push({ lesson, course, progress: p, strength });
  }
  // Weakest first, then oldest review
  candidates.sort((a, b) => {
    if (a.strength !== b.strength) return a.strength - b.strength;
    const aTime = new Date(a.progress.last_reviewed_at ?? a.progress.completed_at ?? 0).getTime();
    const bTime = new Date(b.progress.last_reviewed_at ?? b.progress.completed_at ?? 0).getTime();
    return aTime - bTime;
  });
  return candidates;
}

export type PracticeResult = {
  correct: boolean;
  xpAwarded: number;
  newStrength: number;
  newlyUnlocked: string[];
};

export async function completePractice(
  userId: string,
  lessonId: string,
  correct: boolean
): Promise<PracticeResult> {
  // Practice XP is intentionally smaller than the lesson's full reward.
  // Correct: 5 XP. Incorrect: 0 XP. This keeps practice meaningful without
  // letting users farm XP by re-practicing the same lesson forever.
  const xpAwarded = correct ? 5 : 0;

  // Log the practice session (append-only)
  const { error: logError } = await supabase
    .from('practice_sessions')
    .insert({
      user_id: userId,
      lesson_id: lessonId,
      correct,
      xp_earned: xpAwarded,
    });
  if (logError) throw logError;

  // Update lesson_progress review stats + strength
  const { data: existing } = await supabase
    .from('lesson_progress')
    .select('*')
    .eq('user_id', userId)
    .eq('lesson_id', lessonId)
    .maybeSingle();

  const prev = (existing ?? {}) as Partial<LessonProgress>;
  const newReviewCount = (prev.review_count ?? 0) + 1;
  const newTimesCorrect = (prev.times_correct ?? 0) + (correct ? 1 : 0);
  const newTimesIncorrect = (prev.times_incorrect ?? 0) + (correct ? 0 : 1);
  // A correct review restores strength to 1.0 (full). An incorrect review
  // only partially restores it (0.6) so the lesson stays flagged for more
  // practice.
  const newStrength = correct ? 1.0 : 0.6;

  await supabase
    .from('lesson_progress')
    .update({
      strength: newStrength,
      last_reviewed_at: new Date().toISOString(),
      review_count: newReviewCount,
      times_correct: newTimesCorrect,
      times_incorrect: newTimesIncorrect,
    })
    .eq('user_id', userId)
    .eq('lesson_id', lessonId);

  // Award XP to profile + update streak
  if (xpAwarded > 0) {
    const { data: profile } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .maybeSingle();

    if (profile) {
      const today = new Date().toISOString().split('T')[0];
      const lastActivity = profile.last_activity_date;
      let newStreak = profile.current_streak;

      if (lastActivity !== today) {
        if (lastActivity) {
          const yesterday = new Date();
          yesterday.setDate(yesterday.getDate() - 1);
          const yesterdayStr = yesterday.toISOString().split('T')[0];
          if (lastActivity === yesterdayStr) {
            newStreak = profile.current_streak + 1;
          } else {
            newStreak = 1;
          }
        } else {
          newStreak = 1;
        }
      }

      await supabase
        .from('profiles')
        .update({
          total_xp: profile.total_xp + xpAwarded,
          current_streak: newStreak,
          longest_streak: Math.max(profile.longest_streak, newStreak),
          last_activity_date: today,
        })
        .eq('id', userId);
    }
  }

  // Check practice-related achievements
  const [allSessions, allProgress, allAchievements, userAchievements] = await Promise.all([
    fetchPracticeSessions(userId),
    fetchUserProgress(userId),
    fetchAchievements(),
    fetchUserAchievements(userId),
  ]);

  const unlockedSlugs = new Set(
    userAchievements.map((ua) => allAchievements.find((a) => a.id === ua.achievement_id)?.slug).filter(Boolean) as string[]
  );

  const newlyUnlocked: string[] = [];
  const check = (slug: string, condition: boolean) => {
    if (condition && !unlockedSlugs.has(slug)) newlyUnlocked.push(slug);
  };

  check('practice_10', allSessions.length >= 10);
  check('practice_50', allSessions.length >= 50);

  // Current correct streak in practice sessions (most recent first)
  let correctStreak = 0;
  for (const s of allSessions) {
    if (s.correct) correctStreak++;
    else break;
  }
  check('sharp_shooter', correctStreak >= 10);

  // Count lessons at full strength
  const fullStrengthCount = allProgress.filter(
    (p) => p.status === 'completed' && getEffectiveStrength(p) >= 0.99
  ).length;
  check('review_master', fullStrengthCount >= 5);

  for (const slug of newlyUnlocked) {
    const achievement = allAchievements.find((a) => a.slug === slug);
    if (achievement) {
      const { error } = await supabase
        .from('user_achievements')
        .insert({ user_id: userId, achievement_id: achievement.id });
      if (error && !error.message.includes('duplicate')) {
        console.error('Failed to unlock achievement:', error);
      }
    }
  }

  return { correct, xpAwarded, newStrength, newlyUnlocked };
}
