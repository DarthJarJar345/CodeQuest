import { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import AuthScreen from './components/AuthScreen';
import AppShell, { Tab } from './components/AppShell';
import LearnView from './components/LearnView';
import PracticeView from './components/PracticeView';
import AchievementsView from './components/AchievementsView';
import ProfileView from './components/ProfileView';
import { Code2 } from 'lucide-react';

function AppContent() {
  const { user, loading } = useAuth();
  const [activeTab, setActiveTab] = useState<Tab>('learn');

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-brand-50 via-slate-50 to-accent-50">
        <div className="text-center">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-gradient-to-br from-brand-500 to-brand-700 shadow-xl shadow-brand-500/30 mb-4 animate-bounce-in">
            <Code2 className="w-10 h-10 text-white" strokeWidth={2.5} />
          </div>
          <div className="w-8 h-8 border-4 border-brand-200 border-t-brand-500 rounded-full animate-spin mx-auto" />
        </div>
      </div>
    );
  }

  if (!user) {
    return <AuthScreen />;
  }

  return (
    <AppShell activeTab={activeTab} onTabChange={setActiveTab}>
      {activeTab === 'learn' && <LearnView onNavigatePractice={() => setActiveTab('practice')} />}
      {activeTab === 'practice' && <PracticeView />}
      {activeTab === 'achievements' && <AchievementsView />}
      {activeTab === 'profile' && <ProfileView />}
    </AppShell>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
