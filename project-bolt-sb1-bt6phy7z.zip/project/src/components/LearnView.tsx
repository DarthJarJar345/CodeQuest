import { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { Course, Lesson, LessonProgress } from '../lib/supabase';
import { fetchCourses, fetchLessonsByCourse, fetchAllLessons, fetchUserProgress, getEffectiveStrength } from '../lib/api';
import { ChevronRight, Lock, Check, Star, Play, ArrowLeft, Dumbbell } from 'lucide-react';
import LessonView from './LessonView';

type View = 'catalog' | 'path' | 'lesson';

type Props = {
  onNavigatePractice?: () => void;
};

export default function LearnView({ onNavigatePractice }: Props) {
  const { user } = useAuth();
  const [view, setView] = useState<View>('catalog');
  const [courses, setCourses] = useState<Course[]>([]);
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [allLessons, setAllLessons] = useState<Lesson[]>([]);
  const [progress, setProgress] = useState<LessonProgress[]>([]);
  const [selectedLesson, setSelectedLesson] = useState<Lesson | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    Promise.all([
      fetchCourses(),
      fetchAllLessons(),
      fetchUserProgress(user.id),
    ]).then(([c, al, p]) => {
      setCourses(c);
      setAllLessons(al);
      setProgress(p);
      setLoading(false);
    }).catch((err) => {
      console.error('Failed to load data:', err);
      setLoading(false);
    });
  }, [user]);

  const loadCourse = async (course: Course) => {
    setSelectedCourse(course);
    setView('path');
    const l = await fetchLessonsByCourse(course.id);
    setLessons(l);
  };

  const handleLessonComplete = () => {
    if (!user) return;
    fetchUserProgress(user.id).then(setProgress);
    setView('path');
  };

  const completedLessonIds = new Set(
    progress.filter((p) => p.status === 'completed').map((p) => p.lesson_id)
  );

  const progressByLesson = new Map(
    progress.filter((p) => p.status === 'completed').map((p) => [p.lesson_id, p])
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-8 h-8 border-4 border-brand-200 border-t-brand-500 rounded-full animate-spin" />
      </div>
    );
  }

  if (view === 'lesson' && selectedLesson && selectedCourse) {
    const currentIdx = lessons.findIndex((l) => l.id === selectedLesson.id);
    const nextLesson = currentIdx >= 0 && currentIdx < lessons.length - 1
      ? lessons[currentIdx + 1]
      : null;

    const handleNextLesson = () => {
      if (nextLesson) {
        setSelectedLesson(nextLesson);
      }
    };

    return (
      <LessonView
        lesson={selectedLesson}
        course={selectedCourse}
        nextLesson={nextLesson}
        onBack={() => setView('path')}
        onComplete={handleLessonComplete}
        onNextLesson={nextLesson ? handleNextLesson : undefined}
      />
    );
  }

  if (view === 'path' && selectedCourse) {
    const completedCount = lessons.filter((l) => completedLessonIds.has(l.id)).length;
    const pct = lessons.length > 0 ? (completedCount / lessons.length) * 100 : 0;

    const courseProgress = progress.filter(
      (p) => p.status === 'completed' && lessons.some((l) => l.id === p.lesson_id)
    );
    const weakInCourse = courseProgress.filter((p) => getEffectiveStrength(p) < 0.5).length;

    return (
      <div className="animate-fade-in">
        <button
          onClick={() => setView('catalog')}
          className="flex items-center gap-2 text-slate-500 hover:text-slate-700 font-bold mb-6 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          All Courses
        </button>

        <div className="flex items-center gap-4 mb-8">
          <div
            className="flex items-center justify-center w-16 h-16 rounded-3xl text-4xl shadow-lg"
            style={{ backgroundColor: `${selectedCourse.color}15` }}
          >
            {selectedCourse.icon}
          </div>
          <div className="flex-1">
            <h1 className="text-2xl font-extrabold text-slate-800">{selectedCourse.title}</h1>
            <p className="text-slate-500 font-semibold text-sm">{selectedCourse.description}</p>
          </div>
          {weakInCourse > 0 && (
            <button
              onClick={onNavigatePractice}
              className="flex items-center gap-1.5 px-3 py-2 rounded-2xl bg-accent-50 border border-accent-200 hover:bg-accent-100 active:scale-95 transition-all"
            >
              <Dumbbell className="w-4 h-4 text-accent-500" />
              <span className="text-xs font-extrabold text-accent-700">{weakInCourse} to review</span>
            </button>
          )}
        </div>

        {/* Progress bar */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-bold text-slate-600">Course Progress</span>
            <span className="text-sm font-bold text-slate-400">{completedCount}/{lessons.length}</span>
          </div>
          <div className="h-3 rounded-full bg-slate-100 overflow-hidden">
            <div
              className="h-full rounded-full transition-all duration-500"
              style={{ width: `${pct}%`, backgroundColor: selectedCourse.color }}
            />
          </div>
        </div>

        {/* Strength legend */}
        {completedCount > 0 && (
          <div className="mb-8 flex flex-wrap items-center gap-x-4 gap-y-1.5 text-xs font-semibold text-slate-500">
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: selectedCourse.color }} />
              Fresh
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-accent-500" />
              Needs review
            </span>
            <span className="flex items-center gap-1.5 text-slate-400">
              <Dumbbell className="w-3 h-3" />
              Tap a reviewed node to practice
            </span>
          </div>
        )}

        {/* Learning path - Duolingo style */}
        <div className="flex flex-col items-center gap-1 py-4">
          {lessons.map((lesson, idx) => {
            const isCompleted = completedLessonIds.has(lesson.id);
            const isLocked = idx > 0 && !completedLessonIds.has(lessons[idx - 1].id);
            const isCurrent = !isCompleted && !isLocked;

            const prog = progressByLesson.get(lesson.id);
            const strength = prog ? getEffectiveStrength(prog) : 0;
            const needsReview = isCompleted && strength < 0.5;
            const strengthPct = Math.round(strength * 100);

            // Zigzag positioning
            const offset = Math.sin(idx * 0.8) * 60;

            return (
              <div
                key={lesson.id}
                className="flex flex-col items-center"
                style={{ transform: `translateX(${offset}px)` }}
              >
                {isCurrent && (
                  <div className="mb-2 px-3 py-1 rounded-full bg-brand-500 text-white text-xs font-bold animate-bounce">
                    START
                  </div>
                )}
                {needsReview && (
                  <div className="mb-2 px-2.5 py-1 rounded-full bg-accent-500 text-white text-[10px] font-bold flex items-center gap-1 animate-bounce">
                    <Dumbbell className="w-2.5 h-2.5" />
                    REVIEW
                  </div>
                )}
                <button
                  onClick={() => !isLocked && (setSelectedLesson(lesson), setView('lesson'))}
                  disabled={isLocked}
                  className={`lesson-node w-16 h-16 text-xl font-extrabold ${
                    isCompleted
                      ? 'shadow-lg'
                      : isLocked
                      ? 'bg-slate-200 text-slate-400'
                      : 'shadow-xl hover:scale-110 active:scale-95'
                  }`}
                  style={
                    isCompleted
                      ? needsReview
                        ? { backgroundColor: '#f59e0b', color: 'white' }
                        : { backgroundColor: selectedCourse.color, color: 'white' }
                      : isCurrent
                      ? { backgroundColor: 'white', border: `4px solid ${selectedCourse.color}`, color: selectedCourse.color }
                      : {}
                  }
                >
                  {isCompleted ? (
                    needsReview ? (
                      <Dumbbell className="w-6 h-6" strokeWidth={2.5} />
                    ) : (
                      <Check className="w-6 h-6" strokeWidth={3} />
                    )
                  ) : isLocked ? (
                    <Lock className="w-5 h-5" />
                  ) : (
                    <Play className="w-5 h-5 fill-current" />
                  )}
                  {isCurrent && (
                    <span
                      className="absolute -inset-1 rounded-full animate-pulse-ring"
                      style={{ border: `3px solid ${selectedCourse.color}` }}
                    />
                  )}
                  {isCompleted && !needsReview && strengthPct < 100 && (
                    <svg
                      className="absolute -inset-1 w-[calc(100%+8px)] h-[calc(100%+8px)] -rotate-90 pointer-events-none"
                      viewBox="0 0 36 36"
                    >
                      <circle cx="18" cy="18" r="16" fill="none" stroke="rgba(255,255,255,0.35)" strokeWidth="2" />
                      <circle
                        cx="18" cy="18" r="16" fill="none" stroke="white" strokeWidth="2"
                        strokeDasharray={`${strengthPct} 100`}
                        strokeLinecap="round"
                      />
                    </svg>
                  )}
                </button>
                <div className="mt-1 text-center max-w-[120px]">
                  <p className={`text-[11px] font-bold ${isLocked ? 'text-slate-300' : 'text-slate-600'}`}>
                    {lesson.title}
                  </p>
                  <p className="text-[9px] text-slate-400 font-semibold mt-0.5 flex items-center justify-center gap-0.5">
                    <Star className="w-2.5 h-2.5 fill-accent-400 text-accent-400" />
                    {lesson.xp_reward} XP
                  </p>
                </div>
                {idx < lessons.length - 1 && (
                  <div
                    className="w-1 h-6 rounded-full my-0.5"
                    style={{ backgroundColor: isCompleted ? selectedCourse.color : '#e2e8f0' }}
                  />
                )}
              </div>
            );
          })}
        </div>
      </div>
    );
  }

  // Course catalog with per-course progress
  return (
    <div className="animate-fade-in">
      <div className="mb-6">
        <h1 className="text-2xl font-extrabold text-slate-800">Choose a Course</h1>
        <p className="text-slate-500 font-semibold text-sm mt-1">Pick a path and start your coding journey</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        {courses.map((course) => {
          const courseLessons = allLessons.filter((l) => l.course_id === course.id);
          const completedCount = courseLessons.filter((l) => completedLessonIds.has(l.id)).length;
          const pct = courseLessons.length > 0 ? (completedCount / courseLessons.length) * 100 : 0;

          return (
            <button
              key={course.id}
              onClick={() => loadCourse(course)}
              className="card p-5 text-left hover:shadow-lg hover:-translate-y-0.5 transition-all duration-200 group"
            >
              <div className="flex items-start gap-4">
                <div
                  className="flex items-center justify-center w-14 h-14 rounded-2xl text-3xl flex-shrink-0 group-hover:scale-110 transition-transform"
                  style={{ backgroundColor: `${course.color}15` }}
                >
                  {course.icon}
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-extrabold text-slate-800 text-lg">{course.title}</h3>
                  <p className="text-sm text-slate-500 font-semibold line-clamp-2 mt-0.5">
                    {course.description}
                  </p>
                  {completedCount > 0 && (
                    <div className="mt-3">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs font-bold text-slate-400">{completedCount}/{courseLessons.length} lessons</span>
                        <span className="text-xs font-bold" style={{ color: course.color }}>{Math.round(pct)}%</span>
                      </div>
                      <div className="h-1.5 rounded-full bg-slate-100 overflow-hidden">
                        <div
                          className="h-full rounded-full transition-all duration-500"
                          style={{ width: `${pct}%`, backgroundColor: course.color }}
                        />
                      </div>
                    </div>
                  )}
                </div>
                <ChevronRight className="w-5 h-5 text-slate-300 group-hover:text-slate-500 group-hover:translate-x-1 transition-all flex-shrink-0" />
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
