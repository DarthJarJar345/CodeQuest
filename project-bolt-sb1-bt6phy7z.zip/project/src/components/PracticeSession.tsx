import { useState, useRef } from 'react';
import { Lesson, Course } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { completePractice } from '../lib/api';
import { executeCode } from '../lib/codeEngine';
import {
  ArrowLeft, Play, RotateCcw, Check, X, Star, Trophy,
  Lightbulb, Terminal, Eye, Brain, Target, Zap,
} from 'lucide-react';
import Confetti from './Confetti';

type Props = {
  lesson: Lesson;
  course: Course;
  strengthBefore: number;
  onBack: () => void;
  onComplete: (result: { correct: boolean; xpAwarded: number; newStrength: number }) => void;
};

type Phase = 'challenge' | 'success' | 'fail';

export default function PracticeSession({ lesson, course, strengthBefore, onBack, onComplete }: Props) {
  const { user, refreshProfile } = useAuth();
  const [phase, setPhase] = useState<Phase>('challenge');
  const [code, setCode] = useState(lesson.challenge.starter_code);
  const [output, setOutput] = useState('');
  const [preview, setPreview] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [passed, setPassed] = useState(false);
  const [running, setRunning] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const [hintLevel, setHintLevel] = useState(0);
  const [showFailOption, setShowFailOption] = useState(false);
  const [xpEarned, setXpEarned] = useState(0);
  const [newStrength, setNewStrength] = useState(strengthBefore);
  const [newAchievements, setNewAchievements] = useState<string[]>([]);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const isHtmlCss = course.language.toLowerCase().includes('html');
  const hints = lesson.challenge.hints || [lesson.challenge.solution.split('\n')[0]];

  const runCode = () => {
    setRunning(true);
    setError(null);
    setOutput('');
    setPreview(null);
    setPassed(false);
    setShowFailOption(false);

    const result = executeCode(code, course.language);

    setOutput(result.output);
    if (result.error) {
      setError(result.error);
      setRunning(false);
      return;
    }
    if (result.preview) setPreview(result.preview);

    const tests = lesson.challenge.tests;
    let allPassed = true;
    for (const test of tests) {
      if (test.type === 'output_match') {
        const normalized = result.output.trim().replace(/\r\n/g, '\n');
        const expected = test.expected.trim().replace(/\r\n/g, '\n');
        if (normalized !== expected) { allPassed = false; break; }
      } else if (test.type === 'contains') {
        if (!code.includes(test.expected) && !result.output.includes(test.expected)) {
          allPassed = false; break;
        }
      }
    }

    setPassed(allPassed);
    if (allPassed) {
      handleSubmit(true);
    } else {
      setShowFailOption(true);
    }
    setRunning(false);
  };

  const handleSubmit = async (correct: boolean) => {
    if (!user || submitting) return;
    setSubmitting(true);
    try {
      const result = await completePractice(user.id, lesson.id, correct);
      setXpEarned(result.xpAwarded);
      setNewStrength(result.newStrength);
      setNewAchievements(result.newlyUnlocked);
      setPhase(correct ? 'success' : 'fail');
      await refreshProfile();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save practice');
      setPassed(false);
    }
    setSubmitting(false);
  };

  const resetCode = () => {
    setCode(lesson.challenge.starter_code);
    setOutput('');
    setPreview(null);
    setError(null);
    setPassed(false);
    setShowFailOption(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Tab') {
      e.preventDefault();
      const start = e.currentTarget.selectionStart;
      const end = e.currentTarget.selectionEnd;
      const newCode = code.substring(0, start) + '  ' + code.substring(end);
      setCode(newCode);
      requestAnimationFrame(() => {
        if (textareaRef.current) {
          textareaRef.current.selectionStart = textareaRef.current.selectionEnd = start + 2;
        }
      });
    }
  };

  const strengthPct = Math.round(strengthBefore * 100);
  const newStrengthPct = Math.round(newStrength * 100);

  if (phase === 'success') {
    return (
      <div className="animate-fade-in">
        <Confetti />
        <div className="flex flex-col items-center justify-center py-12 text-center">
          <div className="w-24 h-24 rounded-full bg-gradient-to-br from-success-400 to-success-600 flex items-center justify-center mb-6 animate-bounce-in shadow-xl shadow-success-500/30">
            <Brain className="w-12 h-12 text-white" strokeWidth={2.5} />
          </div>
          <h2 className="text-3xl font-extrabold text-slate-800 mb-2">Skill Restored!</h2>
          <p className="text-slate-500 font-semibold mb-6">
            Nice work — this lesson is back to full strength.
          </p>

          <div className="flex items-center gap-6 mb-6">
            <div className="flex flex-col items-center">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wide mb-1">Before</span>
              <div className="relative w-16 h-16">
                <svg className="w-16 h-16 -rotate-90" viewBox="0 0 36 36">
                  <circle cx="18" cy="18" r="15.5" fill="none" stroke="#e2e8f0" strokeWidth="3.5" />
                  <circle
                    cx="18" cy="18" r="15.5" fill="none" stroke="#f59e0b" strokeWidth="3.5"
                    strokeDasharray={`${strengthPct} 100`}
                    strokeLinecap="round"
                  />
                </svg>
                <span className="absolute inset-0 flex items-center justify-center text-sm font-extrabold text-slate-600">
                  {strengthPct}%
                </span>
              </div>
            </div>
            <div className="flex items-center justify-center w-10 h-10 rounded-full bg-brand-50">
              <Zap className="w-5 h-5 text-brand-500" />
            </div>
            <div className="flex flex-col items-center">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wide mb-1">After</span>
              <div className="relative w-16 h-16">
                <svg className="w-16 h-16 -rotate-90" viewBox="0 0 36 36">
                  <circle cx="18" cy="18" r="15.5" fill="none" stroke="#e2e8f0" strokeWidth="3.5" />
                  <circle
                    cx="18" cy="18" r="15.5" fill="none" stroke="#22c55e" strokeWidth="3.5"
                    strokeDasharray={`${newStrengthPct} 100`}
                    strokeLinecap="round"
                  />
                </svg>
                <span className="absolute inset-0 flex items-center justify-center text-sm font-extrabold text-success-600">
                  {newStrengthPct}%
                </span>
              </div>
            </div>
          </div>

          {xpEarned > 0 && (
            <div className="flex items-center gap-2 px-6 py-3 rounded-2xl bg-accent-50 border-2 border-accent-200 mb-6 animate-pop">
              <Star className="w-6 h-6 fill-accent-400 text-accent-500" />
              <span className="text-2xl font-extrabold text-accent-700">+{xpEarned} XP</span>
            </div>
          )}

          {newAchievements.length > 0 && (
            <div className="w-full max-w-md space-y-2 mb-6">
              <p className="font-bold text-slate-600 text-sm">New Achievements Unlocked!</p>
              {newAchievements.map((slug) => (
                <div key={slug} className="flex items-center gap-3 p-3 rounded-2xl bg-brand-50 border border-brand-100 animate-slide-up">
                  <Trophy className="w-6 h-6 text-brand-500" />
                  <span className="font-bold text-brand-700 capitalize">{slug.replace(/_/g, ' ')}</span>
                </div>
              ))}
            </div>
          )}

          <button onClick={() => onComplete({ correct: true, xpAwarded: xpEarned, newStrength })} className="btn-primary">
            Continue
          </button>
        </div>
      </div>
    );
  }

  if (phase === 'fail') {
    return (
      <div className="animate-fade-in">
        <div className="flex flex-col items-center justify-center py-12 text-center">
          <div className="w-24 h-24 rounded-full bg-gradient-to-br from-accent-400 to-accent-600 flex items-center justify-center mb-6 animate-bounce-in shadow-xl shadow-accent-500/30">
            <Target className="w-12 h-12 text-white" strokeWidth={2.5} />
          </div>
          <h2 className="text-3xl font-extrabold text-slate-800 mb-2">Almost There!</h2>
          <p className="text-slate-500 font-semibold mb-6 max-w-md">
            That one needs another try. Review the hint below, then give it another shot —
            you've got this.
          </p>

          <div className="card p-4 max-w-md w-full mb-6 text-left bg-accent-50 border-accent-200">
            <div className="flex gap-3">
              <Lightbulb className="w-5 h-5 text-accent-500 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-accent-800 text-sm mb-1">Solution hint</p>
                <pre className="text-xs text-accent-700 font-mono whitespace-pre-wrap bg-white/60 rounded-lg p-2 mt-1">
                  {lesson.challenge.solution}
                </pre>
              </div>
            </div>
          </div>

          <div className="flex gap-3">
            <button
              onClick={() => { resetCode(); setPhase('challenge'); }}
              className="btn-secondary flex items-center gap-2"
            >
              <RotateCcw className="w-5 h-5" />
              Try Again
            </button>
            <button onClick={() => onComplete({ correct: false, xpAwarded: 0, newStrength })} className="btn-primary">
              Continue
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="animate-fade-in">
      <button
        onClick={onBack}
        className="flex items-center gap-2 text-slate-500 hover:text-slate-700 font-bold mb-4 transition-colors"
      >
        <ArrowLeft className="w-5 h-5" />
        Back to Practice
      </button>

      {/* Practice banner */}
      <div className="card p-5 mb-4 bg-gradient-to-br from-brand-50 to-accent-50 border-brand-100">
        <div className="flex items-center gap-4">
          <div
            className="flex items-center justify-center w-14 h-14 rounded-2xl text-2xl flex-shrink-0"
            style={{ backgroundColor: `${course.color}15` }}
          >
            {course.icon}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <Brain className="w-4 h-4 text-brand-500" />
              <span className="text-xs font-extrabold text-brand-600 uppercase tracking-wide">Practice</span>
            </div>
            <h1 className="text-lg font-extrabold text-slate-800 truncate">{lesson.title}</h1>
            <p className="text-sm text-slate-500 font-semibold truncate">{course.title}</p>
          </div>
          <div className="flex flex-col items-end flex-shrink-0">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wide">Strength</span>
            <span
              className="text-lg font-extrabold"
              style={{ color: strengthPct >= 50 ? '#3399ff' : '#f59e0b' }}
            >
              {strengthPct}%
            </span>
          </div>
        </div>
      </div>

      {/* Challenge prompt */}
      <div className="card p-6">
        <p className="text-slate-600 font-semibold mb-4">{lesson.challenge.prompt}</p>
        <div className="flex items-center gap-2 text-sm">
          <Star className="w-4 h-4 fill-accent-400 text-accent-400" />
          <span className="font-bold text-slate-500">Earn up to 5 XP for a correct review</span>
        </div>
      </div>

      {/* Code editor */}
      <div className="card overflow-hidden mt-4">
        <div className="flex items-center justify-between px-4 py-2.5 bg-slate-800 border-b border-slate-700">
          <div className="flex items-center gap-2">
            <div className="flex gap-1.5">
              <div className="w-3 h-3 rounded-full bg-error-400" />
              <div className="w-3 h-3 rounded-full bg-accent-400" />
              <div className="w-3 h-3 rounded-full bg-success-400" />
            </div>
            <span className="text-xs font-bold text-slate-400 ml-2 font-mono">
              {course.language.toLowerCase()}
            </span>
          </div>
          <button
            onClick={resetCode}
            className="flex items-center gap-1 text-xs font-bold text-slate-400 hover:text-slate-200 transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            Reset
          </button>
        </div>
        <textarea
          ref={textareaRef}
          value={code}
          onChange={(e) => setCode(e.target.value)}
          onKeyDown={handleKeyDown}
          spellCheck={false}
          className="code-editor w-full min-h-[200px] px-4 py-3 bg-slate-900 text-slate-100 font-mono text-sm outline-none resize-y leading-relaxed"
          placeholder="Write your code here..."
        />
      </div>

      {/* Action buttons */}
      <div className="flex gap-3 mt-4">
        <button
          onClick={runCode}
          disabled={running || submitting}
          className="btn-primary flex-1 flex items-center justify-center gap-2"
        >
          {running || submitting ? (
            <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
          ) : (
            <>
              <Play className="w-5 h-5 fill-current" />
              Run & Check
            </>
          )}
        </button>
        <button
          onClick={() => { setShowHint(!showHint); setHintLevel(0); }}
          className="btn-secondary flex items-center gap-2"
        >
          <Lightbulb className="w-5 h-5" />
          Hint
        </button>
      </div>

      {/* Progressive hints */}
      {showHint && (
        <div className="card p-4 border-accent-200 bg-accent-50 animate-slide-up mt-4">
          <div className="flex gap-3">
            <Lightbulb className="w-5 h-5 text-accent-500 flex-shrink-0 mt-0.5" />
            <div className="flex-1">
              <p className="font-bold text-accent-800 text-sm mb-1">Hint {hintLevel + 1} of {hints.length}</p>
              <p className="text-sm text-accent-700 font-semibold mb-2">{hints[hintLevel]}</p>
              {hintLevel < hints.length - 1 && (
                <button
                  onClick={() => setHintLevel(hintLevel + 1)}
                  className="text-xs font-bold text-accent-600 hover:text-accent-800 transition-colors"
                >
                  Need another hint? →
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* HTML Preview */}
      {isHtmlCss && preview && (
        <div className="card overflow-hidden animate-slide-up mt-4">
          <div className="px-4 py-2.5 bg-slate-800 border-b border-slate-700">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-400">
              <Eye className="w-3.5 h-3.5" />
              PREVIEW
            </div>
          </div>
          <div className="p-4 bg-white">
            <iframe srcDoc={preview} className="w-full min-h-[150px] border-0" title="HTML Preview" sandbox="allow-same-origin" />
          </div>
        </div>
      )}

      {/* Output */}
      {output && (
        <div className="card overflow-hidden animate-slide-up mt-4">
          <div className="px-4 py-2.5 bg-slate-800 border-b border-slate-700">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-400">
              <Terminal className="w-3.5 h-3.5" />
              OUTPUT
            </div>
          </div>
          <div className="p-4 bg-slate-900 min-h-[60px]">
            <pre className={`text-sm font-mono whitespace-pre-wrap ${error ? 'text-error-400' : 'text-slate-100'}`}>
              {output}
            </pre>
          </div>
        </div>
      )}

      {/* Error */}
      {error && (
        <div className="flex items-start gap-2 p-4 rounded-2xl bg-error-50 border border-error-200 animate-shake mt-4">
          <X className="w-5 h-5 text-error-500 flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-bold text-error-700 text-sm">Error</p>
            <p className="text-sm text-error-600 font-mono mt-1">{error}</p>
          </div>
        </div>
      )}

      {/* Success */}
      {passed && !error && (
        <div className="flex items-start gap-2 p-4 rounded-2xl bg-success-50 border border-success-200 animate-slide-up mt-4">
          <Check className="w-5 h-5 text-success-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-bold text-success-700 text-sm">Correct! Saving your practice...</p>
          </div>
        </div>
      )}

      {/* Not-quite-right: offer to reveal the answer */}
      {showFailOption && !passed && !error && (
        <div className="card p-4 border-accent-200 bg-accent-50 animate-slide-up mt-4">
          <div className="flex items-start gap-3">
            <Target className="w-5 h-5 text-accent-500 flex-shrink-0 mt-0.5" />
            <div className="flex-1">
              <p className="font-bold text-accent-800 text-sm mb-1">Not quite there yet</p>
              <p className="text-xs text-accent-700 font-semibold mb-3">
                Your output doesn't match yet. Keep trying, or reveal the solution to move on.
              </p>
              <div className="flex gap-2">
                <button
                  onClick={() => { setShowHint(true); setShowFailOption(false); }}
                  className="px-3 py-1.5 rounded-xl bg-white text-accent-600 text-xs font-bold border border-accent-200 hover:bg-accent-100 transition-colors"
                >
                  Show Hint
                </button>
                <button
                  onClick={() => handleSubmit(false)}
                  disabled={submitting}
                  className="px-3 py-1.5 rounded-xl bg-accent-500 text-white text-xs font-bold hover:bg-accent-600 transition-colors disabled:opacity-50"
                >
                  Reveal Solution
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
