import { ReactNode } from 'react';
import { useAuth } from '../context/AuthContext';
import { Flame, Trophy, Home, User, LogOut, Code2, Dumbbell } from 'lucide-react';

export type Tab = 'learn' | 'practice' | 'achievements' | 'profile';

type Props = {
  activeTab: Tab;
  onTabChange: (tab: Tab) => void;
  children: ReactNode;
};

export default function AppShell({ activeTab, onTabChange, children }: Props) {
  const { profile, signOut } = useAuth();

  const navItems: { id: Tab; label: string; icon: typeof Home }[] = [
    { id: 'learn', label: 'Learn', icon: Home },
    { id: 'practice', label: 'Practice', icon: Dumbbell },
    { id: 'achievements', label: 'Awards', icon: Trophy },
    { id: 'profile', label: 'Profile', icon: User },
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Top bar */}
      <header className="sticky top-0 z-40 bg-white/80 backdrop-blur-md border-b border-slate-100">
        <div className="max-w-5xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="flex items-center justify-center w-9 h-9 rounded-xl bg-gradient-to-br from-brand-500 to-brand-700">
              <Code2 className="w-5 h-5 text-white" strokeWidth={2.5} />
            </div>
            <span className="text-xl font-extrabold text-slate-800 tracking-tight hidden sm:block">
              CodeQuest
            </span>
          </div>

          {/* Stats */}
          <div className="flex items-center gap-3 sm:gap-5">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-accent-50 border border-accent-100">
              <Flame className="w-4 h-4 text-accent-500 fill-accent-400" />
              <span className="font-extrabold text-accent-700 text-sm">{profile?.current_streak ?? 0}</span>
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-brand-50 border border-brand-100">
              <Trophy className="w-4 h-4 text-brand-500" />
              <span className="font-extrabold text-brand-700 text-sm">{profile?.total_xp ?? 0} XP</span>
            </div>
            <button
              onClick={signOut}
              className="p-2 rounded-xl hover:bg-slate-100 transition-colors text-slate-400 hover:text-slate-600"
              title="Sign out"
            >
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      {/* Main content */}
      <main className="max-w-5xl mx-auto px-4 py-6 pb-28 md:pb-8">
        {children}
      </main>

      {/* Bottom nav (mobile) */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/90 backdrop-blur-md border-t border-slate-100 md:hidden">
        <div className="flex items-center justify-around h-16 px-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onTabChange(item.id)}
                className={`flex flex-col items-center gap-0.5 px-4 py-2 rounded-xl transition-all ${
                  active ? 'text-brand-600' : 'text-slate-400'
                }`}
              >
                <Icon className={`w-6 h-6 ${active ? 'scale-110' : ''} transition-transform`} strokeWidth={active ? 2.5 : 2} />
                <span className="text-xs font-bold">{item.label}</span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* Side nav (desktop) — integrated into top bar style */}
      <nav className="hidden md:block fixed left-0 top-16 bottom-0 w-56 border-r border-slate-100 bg-white/50">
        <div className="p-4 space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onTabChange(item.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl font-bold transition-all ${
                  active
                    ? 'bg-brand-50 text-brand-600'
                    : 'text-slate-500 hover:bg-slate-100'
                }`}
              >
                <Icon className="w-5 h-5" strokeWidth={active ? 2.5 : 2} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
