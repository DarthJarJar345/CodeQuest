import { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { Achievement, UserAchievement } from '../lib/supabase';
import { fetchAchievements, fetchUserAchievements } from '../lib/api';
import { Lock, Trophy } from 'lucide-react';

export default function AchievementsView() {
  const { user } = useAuth();
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [userAchievements, setUserAchievements] = useState<UserAchievement[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    Promise.all([
      fetchAchievements(),
      fetchUserAchievements(user.id),
    ]).then(([a, ua]) => {
      setAchievements(a);
      setUserAchievements(ua);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, [user]);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-8 h-8 border-4 border-brand-200 border-t-brand-500 rounded-full animate-spin" />
      </div>
    );
  }

  const unlockedIds = new Set(userAchievements.map((ua) => ua.achievement_id));
  const unlockedCount = unlockedIds.size;
  const totalCount = achievements.length;
  const pct = totalCount > 0 ? (unlockedCount / totalCount) * 100 : 0;

  return (
    <div className="animate-fade-in">
      <div className="mb-6">
        <h1 className="text-2xl font-extrabold text-slate-800">Achievements</h1>
        <p className="text-slate-500 font-semibold text-sm mt-1">
          {unlockedCount} of {totalCount} unlocked
        </p>
      </div>

      {/* Progress bar */}
      <div className="mb-8">
        <div className="h-3 rounded-full bg-slate-100 overflow-hidden">
          <div
            className="h-full rounded-full bg-gradient-to-r from-brand-400 to-brand-600 transition-all duration-500"
            style={{ width: `${pct}%` }}
          />
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {achievements.map((achievement) => {
          const unlocked = unlockedIds.has(achievement.id);
          return (
            <div
              key={achievement.id}
              className={`card p-5 text-center transition-all ${
                unlocked
                  ? 'border-brand-200 bg-gradient-to-br from-white to-brand-50'
                  : 'opacity-60'
              }`}
            >
              <div
                className={`mx-auto flex items-center justify-center w-16 h-16 rounded-2xl text-3xl mb-3 ${
                  unlocked
                    ? 'bg-gradient-to-br from-brand-400 to-brand-600 shadow-lg shadow-brand-500/30 animate-pop'
                    : 'bg-slate-200'
                }`}
              >
                {unlocked ? (
                  <span>{achievement.icon}</span>
                ) : (
                  <Lock className="w-7 h-7 text-slate-400" />
                )}
              </div>
              <h3 className={`font-extrabold text-sm ${unlocked ? 'text-slate-800' : 'text-slate-400'}`}>
                {achievement.title}
              </h3>
              <p className={`text-xs font-semibold mt-1 ${unlocked ? 'text-slate-500' : 'text-slate-400'}`}>
                {achievement.description}
              </p>
              {achievement.xp_bonus > 0 && (
                <div className="flex items-center justify-center gap-1 mt-2">
                  <Trophy className="w-3 h-3 text-accent-400" />
                  <span className="text-xs font-bold text-accent-600">+{achievement.xp_bonus} XP</span>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
