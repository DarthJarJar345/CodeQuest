import { useEffect, useMemo, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { Course, Lesson, LessonProgress, PracticeSession as PracticeSessionType } from '../lib/supabase';
import {
  fetchCourses, fetchAllLessons, fetchUserProgress, fetchPracticeSessions,
  getEffectiveStrength, strengthLabel, strengthColor, computeTodayXp,
} from '../lib/api';
import {
  Dumbbell, Brain, Flame, Zap, Target, RefreshCw,
  ChevronRight, Sparkles, AlertCircle, CheckCircle2, Clock,
} from 'lucide-react';
import PracticeSession from './PracticeSession';

type View = 'hub' | 'session';

type ReviewCandidate = {
  lesson: Lesson;
  course: Course;
  progress: LessonProgress;
  strength: number;
};

export default function PracticeView() {
  const { user, profile } = useAuth();
  const [view, setView] = useState<View>('hub');
  const [courses, setCourses] = useState<Course[]>([]);
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [progress, setProgress] = useState<LessonProgress[]>([]);
  const [sessions, setSessions] = useState<PracticeSessionType[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeCandidate, setActiveCandidate] = useState<ReviewCandidate | null>(null);

  useEffect(() => {
    if (!user) return;
    Promise.all([
      fetchCourses(),
      fetchAllLessons(),
      fetchUserProgress(user.id),
      fetchPracticeSessions(user.id),
    ]).then(([c, l, p, s]) => {
      setCourses(c);
      setLessons(l);
      setProgress(p);
      setSessions(s);
      setLoading(false);
    }).catch((err) => {
      console.error('Failed to load practice data:', err);
      setLoading(false);
    });
  }, [user]);

  const candidates = useMemo<ReviewCandidate[]>(() => {
    if (!user || courses.length === 0) return [];
    // fetchReviewCandidates is async but pure over already-loaded data; compute inline
    const completed = progress.filter((p) => p.status === 'completed');
    const lessonById = new Map(lessons.map((l) => [l.id, l]));
    const courseById = new Map(courses.map((c) => [c.id, c]));
    const list: ReviewCandidate[] = [];
    for (const p of completed) {
      const lesson = lessonById.get(p.lesson_id);
      const course = lesson ? courseById.get(lesson.course_id) : undefined;
      if (!lesson || !course) continue;
      list.push({ lesson, course, progress: p, strength: getEffectiveStrength(p) });
    }
    list.sort((a, b) => {
      if (a.strength !== b.strength) return a.strength - b.strength;
      const aTime = new Date(a.progress.last_reviewed_at ?? a.progress.completed_at ?? 0).getTime();
      const bTime = new Date(b.progress.last_reviewed_at ?? b.progress.completed_at ?? 0).getTime();
      return aTime - bTime;
    });
    return list;
  }, [user, courses, lessons, progress]);

  const weakCount = candidates.filter((c) => c.strength < 0.5).length;
  const freshCount = candidates.filter((c) => c.strength >= 0.8).length;
  const totalCompleted = candidates.length;
  const avgStrength = totalCompleted > 0
    ? candidates.reduce((sum, c) => sum + c.strength, 0) / totalCompleted
    : 0;

  const todayKey = new Date().toISOString().split('T')[0];
  const practicedToday = sessions.filter((s) => s.completed_at?.startsWith(todayKey)).length;
  const correctToday = sessions.filter((s) => s.completed_at?.startsWith(todayKey) && s.correct).length;

  const dailyGoal = profile?.daily_goal ?? 30;
  const todayXp = computeTodayXp(progress, sessions);
  const goalPct = Math.min(100, Math.round((todayXp / dailyGoal) * 100));
  const goalMet = todayXp >= dailyGoal;

  const startPractice = (candidate: ReviewCandidate) => {
    setActiveCandidate(candidate);
    setView('session');
  };

  const startDailyPractice = () => {
    // Pick the weakest available lesson, or a random one if all are fresh
    if (candidates.length === 0) return;
    const target = candidates[0];
    startPractice(target);
  };

  const handleSessionComplete = () => {
    if (!user) return;
    // Refresh data then return to hub
    Promise.all([
      fetchUserProgress(user.id),
      fetchPracticeSessions(user.id),
    ]).then(([p, s]) => {
      setProgress(p);
      setSessions(s);
      setActiveCandidate(null);
      setView('hub');
    });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-8 h-8 border-4 border-brand-200 border-t-brand-500 rounded-full animate-spin" />
      </div>
    );
  }

  if (view === 'session' && activeCandidate) {
    return (
      <PracticeSession
        lesson={activeCandidate.lesson}
        course={activeCandidate.course}
        strengthBefore={activeCandidate.strength}
        onBack={() => { setActiveCandidate(null); setView('hub'); }}
        onComplete={handleSessionComplete}
      />
    );
  }

  // Empty state: no completed lessons yet
  if (totalCompleted === 0) {
    return (
      <div className="animate-fade-in">
        <Header practicedToday={0} />
        <div className="card p-8 text-center">
          <div className="mx-auto flex items-center justify-center w-20 h-20 rounded-3xl bg-brand-50 mb-4">
            <Dumbbell className="w-10 h-10 text-brand-400" />
          </div>
          <h2 className="text-xl font-extrabold text-slate-800 mb-2">No skills to practice yet</h2>
          <p className="text-slate-500 font-semibold text-sm max-w-sm mx-auto">
            Complete a few lessons first and they'll show up here for review.
            Practice keeps your skills sharp and your streak alive!
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="animate-fade-in">
      <Header practicedToday={practicedToday} />

      {/* Daily practice CTA */}
      <div className="card p-6 mb-6 bg-gradient-to-br from-brand-500 to-brand-700 border-0 text-white relative overflow-hidden">
        <div className="absolute -right-8 -top-8 w-40 h-40 rounded-full bg-white/10" />
        <div className="absolute -right-4 top-10 w-24 h-24 rounded-full bg-white/5" />
        <div className="relative">
          <div className="flex items-center gap-2 mb-2">
            <Sparkles className="w-5 h-5" />
            <span className="text-xs font-extrabold uppercase tracking-wider text-brand-100">Daily Practice</span>
          </div>
          <h2 className="text-2xl font-extrabold mb-1">Sharpen your skills</h2>
          <p className="text-brand-100 font-semibold text-sm mb-4 max-w-md">
            {weakCount > 0
              ? `You have ${weakCount} skill${weakCount === 1 ? '' : 's'} that need${weakCount === 1 ? 's' : ''} a refresher.`
              : 'All your skills are fresh. Do a quick review to keep them that way!'}
          </p>
          <button
            onClick={startDailyPractice}
            className="flex items-center gap-2 px-5 py-2.5 rounded-2xl bg-white text-brand-600 font-extrabold hover:bg-brand-50 active:scale-95 transition-all shadow-lg"
          >
            <Dumbbell className="w-5 h-5" />
            Start Practice
          </button>
        </div>
      </div>

      {/* Daily goal progress */}
      <div className="card p-5 mb-6">
        <div className="flex items-center gap-4">
          <div className="relative w-16 h-16 flex-shrink-0">
            <svg className="w-16 h-16 -rotate-90" viewBox="0 0 36 36">
              <circle cx="18" cy="18" r="15.5" fill="none" stroke="#e2e8f0" strokeWidth="3.5" />
              <circle
                cx="18" cy="18" r="15.5" fill="none"
                stroke={goalMet ? '#22c55e' : '#3399ff'}
                strokeWidth="3.5"
                strokeDasharray={`${goalPct} 100`}
                strokeLinecap="round"
                className="transition-all duration-500"
              />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center">
              {goalMet ? (
                <CheckCircle2 className="w-7 h-7 text-success-500" />
              ) : (
                <span className="text-xs font-extrabold text-slate-600">{goalPct}%</span>
              )}
            </div>
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              <Flame className="w-4 h-4 text-accent-500 fill-accent-400" />
              <h3 className="font-extrabold text-slate-800">Daily Goal</h3>
            </div>
            <p className="text-sm font-semibold text-slate-500">
              {goalMet
                ? `Goal met! You earned ${todayXp} XP today.`
                : `${todayXp} / ${dailyGoal} XP today — ${dailyGoal - todayXp} XP to go.`}
            </p>
          </div>
        </div>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
        <StatCard
          icon={Brain}
          label="Avg Strength"
          value={`${Math.round(avgStrength * 100)}%`}
          color="text-brand-500"
          bg="bg-brand-50"
        />
        <StatCard
          icon={AlertCircle}
          label="Need Review"
          value={`${weakCount}`}
          color="text-accent-500"
          bg="bg-accent-50"
        />
        <StatCard
          icon={CheckCircle2}
          label="Fresh Skills"
          value={`${freshCount}`}
          color="text-success-600"
          bg="bg-success-50"
        />
        <StatCard
          icon={Zap}
          label="Practiced Today"
          value={`${practicedToday}`}
          color="text-purple-500"
          bg="bg-purple-50"
        />
      </div>

      {/* Today's progress */}
      {practicedToday > 0 && (
        <div className="card p-5 mb-6">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Flame className="w-5 h-5 text-accent-500 fill-accent-400" />
              <h3 className="font-extrabold text-slate-800">Today's Practice</h3>
            </div>
            <span className="text-sm font-bold text-slate-400">
              {correctToday}/{practicedToday} correct
            </span>
          </div>
          <div className="h-2.5 rounded-full bg-slate-100 overflow-hidden">
            <div
              className="h-full rounded-full bg-gradient-to-r from-success-400 to-success-600 transition-all duration-500"
              style={{ width: `${practicedToday > 0 ? (correctToday / practicedToday) * 100 : 0}%` }}
            />
          </div>
        </div>
      )}

      {/* Weak skills list */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Target className="w-5 h-5 text-accent-500" />
            <h3 className="font-extrabold text-slate-800">Skills to Review</h3>
          </div>
          <span className="text-xs font-bold text-slate-400">{candidates.length} total</span>
        </div>

        <div className="space-y-2">
          {candidates.slice(0, 12).map((c) => {
            const label = strengthLabel(c.strength);
            const color = strengthColor(c.strength);
            const pct = Math.round(c.strength * 100);
            return (
              <button
                key={c.lesson.id}
                onClick={() => startPractice(c)}
                className="card p-4 w-full text-left hover:shadow-md hover:-translate-y-0.5 transition-all duration-200 group flex items-center gap-4"
              >
                <div
                  className="flex items-center justify-center w-12 h-12 rounded-2xl text-2xl flex-shrink-0 group-hover:scale-110 transition-transform"
                  style={{ backgroundColor: `${c.course.color}15` }}
                >
                  {c.course.icon}
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="font-extrabold text-slate-800 text-sm truncate">{c.lesson.title}</h4>
                  <p className="text-xs text-slate-400 font-semibold truncate">{c.course.title}</p>
                  <div className="flex items-center gap-2 mt-1.5">
                    <div className="flex-1 h-1.5 rounded-full bg-slate-100 overflow-hidden max-w-[160px]">
                      <div
                        className="h-full rounded-full transition-all duration-500"
                        style={{ width: `${pct}%`, backgroundColor: color }}
                      />
                    </div>
                    <span className="text-xs font-bold" style={{ color }}>{label}</span>
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-slate-300 group-hover:text-slate-500 group-hover:translate-x-1 transition-all flex-shrink-0" />
              </button>
            );
          })}
        </div>
      </div>

      {/* Recent practice history */}
      {sessions.length > 0 && (
        <div>
          <div className="flex items-center gap-2 mb-3">
            <Clock className="w-5 h-5 text-slate-400" />
            <h3 className="font-extrabold text-slate-800">Recent Practice</h3>
          </div>
          <div className="card divide-y divide-slate-100">
            {sessions.slice(0, 6).map((s) => {
              const lesson = lessons.find((l) => l.id === s.lesson_id);
              const course = lesson ? courses.find((c) => c.id === lesson.course_id) : undefined;
              return (
                <div key={s.id} className="p-4 flex items-center gap-3">
                  <div
                    className={`flex items-center justify-center w-9 h-9 rounded-xl flex-shrink-0 ${
                      s.correct ? 'bg-success-50' : 'bg-accent-50'
                    }`}
                  >
                    {s.correct ? (
                      <CheckCircle2 className="w-5 h-5 text-success-500" />
                    ) : (
                      <RefreshCw className="w-5 h-5 text-accent-500" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-bold text-slate-700 text-sm truncate">
                      {lesson?.title ?? 'Unknown lesson'}
                    </p>
                    <p className="text-xs text-slate-400 font-semibold">
                      {course?.title ?? ''} · {timeAgo(s.completed_at)}
                    </p>
                  </div>
                  {s.xp_earned > 0 && (
                    <span className="text-xs font-extrabold text-accent-600 flex items-center gap-0.5">
                      <Zap className="w-3 h-3 fill-accent-400 text-accent-400" />
                      +{s.xp_earned}
                    </span>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

function Header({ practicedToday }: { practicedToday: number }) {
  return (
    <div className="mb-6">
      <div className="flex items-center gap-2 mb-1">
        <Dumbbell className="w-7 h-7 text-brand-500" />
        <h1 className="text-2xl font-extrabold text-slate-800">Practice</h1>
      </div>
      <p className="text-slate-500 font-semibold text-sm">
        {practicedToday > 0
          ? `Great work — ${practicedToday} session${practicedToday === 1 ? '' : 's'} today. Keep it up!`
          : 'Review past lessons to keep your skills sharp and earn XP.'}
      </p>
    </div>
  );
}

function StatCard({
  icon: Icon, label, value, color, bg,
}: {
  icon: typeof Brain;
  label: string;
  value: string;
  color: string;
  bg: string;
}) {
  return (
    <div className="card p-4">
      <div className={`flex items-center justify-center w-10 h-10 rounded-xl ${bg} mb-2`}>
        <Icon className={`w-5 h-5 ${color}`} />
      </div>
      <p className="text-xs font-bold text-slate-400 uppercase tracking-wide">{label}</p>
      <p className="text-lg font-extrabold text-slate-800">{value}</p>
    </div>
  );
}

function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  if (days < 7) return `${days}d ago`;
  return new Date(iso).toLocaleDateString();
}
