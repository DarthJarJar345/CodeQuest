import { useState, useEffect, useRef } from 'react';
import { Lesson, Course } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { completeLesson } from '../lib/api';
import { executeCode } from '../lib/codeEngine';
import { ArrowLeft, Play, RotateCcw, Check, X, Star, Trophy, Lightbulb, Terminal, Eye, ChevronRight } from 'lucide-react';
import Confetti from './Confetti';

type Props = {
  lesson: Lesson;
  course: Course;
  nextLesson?: Lesson | null;
  onBack: () => void;
  onComplete: () => void;
  onNextLesson?: () => void;
};

type Phase = 'learn' | 'challenge' | 'success';

export default function LessonView({ lesson, course, nextLesson, onBack, onComplete, onNextLesson }: Props) {
  const { user, refreshProfile } = useAuth();
  const [phase, setPhase] = useState<Phase>('learn');
  const [code, setCode] = useState(lesson.challenge.starter_code);
  const [output, setOutput] = useState<string>('');
  const [preview, setPreview] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [passed, setPassed] = useState(false);
  const [running, setRunning] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const [hintLevel, setHintLevel] = useState(0);
  const [newAchievements, setNewAchievements] = useState<string[]>([]);
  const [xpEarned, setXpEarned] = useState(0);
  const [alreadyCompleted, setAlreadyCompleted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [showSolution, setShowSolution] = useState(false);
  const [attempts, setAttempts] = useState(0);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    setPhase('learn');
    setCode(lesson.challenge.starter_code);
    setOutput('');
    setPreview(null);
    setError(null);
    setPassed(false);
    setShowHint(false);
    setHintLevel(0);
    setShowSolution(false);
    setAttempts(0);
  }, [lesson]);

  const runCode = () => {
    setRunning(true);
    setError(null);
    setOutput('');
    setPreview(null);
    setPassed(false);

    const result = executeCode(code, course.language);

    setOutput(result.output);
    if (result.error) {
      setError(result.error);
      setRunning(false);
      return;
    }
    if (result.preview) {
      setPreview(result.preview);
    }

    // Check if output matches expected
    const tests = lesson.challenge.tests;
    let allPassed = true;

    for (const test of tests) {
      if (test.type === 'output_match') {
        const normalized = result.output.trim().replace(/\r\n/g, '\n');
        const expected = test.expected.trim().replace(/\r\n/g, '\n');
        if (normalized !== expected) {
          allPassed = false;
          break;
        }
      } else if (test.type === 'contains') {
        if (!code.includes(test.expected) && !result.output.includes(test.expected)) {
          allPassed = false;
          break;
        }
      }
    }

    setPassed(allPassed);
    if (allPassed) {
      handleSubmit();
    } else {
      setAttempts((a) => a + 1);
    }
    setRunning(false);
  };

  const handleSubmit = async () => {
    if (!user || submitting) return;
    setSubmitting(true);

    try {
      const result = await completeLesson(user.id, lesson.id, lesson.xp_reward);
      setXpEarned(result.xpAwarded);
      setAlreadyCompleted(result.alreadyCompleted);
      setNewAchievements(result.newlyUnlocked);
      setPhase('success');
      await refreshProfile();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save progress');
      setPassed(false);
    }
    setSubmitting(false);
  };

  const resetCode = () => {
    setCode(lesson.challenge.starter_code);
    setOutput('');
    setPreview(null);
    setError(null);
    setPassed(false);
    setShowSolution(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Tab') {
      e.preventDefault();
      const start = e.currentTarget.selectionStart;
      const end = e.currentTarget.selectionEnd;
      const newCode = code.substring(0, start) + '  ' + code.substring(end);
      setCode(newCode);
      requestAnimationFrame(() => {
        if (textareaRef.current) {
          textareaRef.current.selectionStart = textareaRef.current.selectionEnd = start + 2;
        }
      });
    }
  };

  if (phase === 'success') {
    return (
      <div className="animate-fade-in">
        <Confetti />
        <div className="flex flex-col items-center justify-center py-12 text-center">
          <div className="w-24 h-24 rounded-full bg-gradient-to-br from-success-400 to-success-600 flex items-center justify-center mb-6 animate-bounce-in shadow-xl shadow-success-500/30">
            <Trophy className="w-12 h-12 text-white" strokeWidth={2.5} />
          </div>
          <h2 className="text-3xl font-extrabold text-slate-800 mb-2">
            {alreadyCompleted ? 'Lesson Reviewed!' : 'Lesson Complete!'}
          </h2>
          <p className="text-slate-500 font-semibold mb-6">
            {alreadyCompleted ? "Great review — you've got this down!" : "Great job, you're getting better every day!"}
          </p>

          {xpEarned > 0 ? (
            <div className="flex items-center gap-2 px-6 py-3 rounded-2xl bg-accent-50 border-2 border-accent-200 mb-6 animate-pop">
              <Star className="w-6 h-6 fill-accent-400 text-accent-500" />
              <span className="text-2xl font-extrabold text-accent-700">+{xpEarned} XP</span>
            </div>
          ) : (
            <div className="flex items-center gap-2 px-6 py-3 rounded-2xl bg-slate-100 border-2 border-slate-200 mb-6">
              <span className="text-sm font-bold text-slate-500">Already completed — no XP awarded for review</span>
            </div>
          )}

          {newAchievements.length > 0 && (
            <div className="w-full max-w-md space-y-2 mb-6">
              <p className="font-bold text-slate-600 text-sm">New Achievements Unlocked!</p>
              {newAchievements.map((slug) => (
                <div key={slug} className="flex items-center gap-3 p-3 rounded-2xl bg-brand-50 border border-brand-100 animate-slide-up">
                  <Trophy className="w-6 h-6 text-brand-500" />
                  <span className="font-bold text-brand-700 capitalize">{slug.replace(/_/g, ' ')}</span>
                </div>
              ))}
            </div>
          )}

          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            {nextLesson && onNextLesson ? (
              <>
                <button onClick={onComplete} className="btn-secondary">
                  Back to Path
                </button>
                <button onClick={onNextLesson} className="btn-primary flex items-center justify-center gap-2">
                  Next Lesson
                  <ChevronRight className="w-5 h-5" />
                </button>
              </>
            ) : (
              <button onClick={onComplete} className="btn-primary">
                Continue Learning
              </button>
            )}
          </div>

          {nextLesson && onNextLesson && (
            <p className="text-sm text-slate-400 font-semibold mt-4">
              Up next: {nextLesson.title}
            </p>
          )}
        </div>
      </div>
    );
  }

  const isHtmlCss = course.language.toLowerCase().includes('html');
  const hints = lesson.challenge.hints || [lesson.challenge.solution.split('\n')[0]];

  return (
    <div className="animate-fade-in">
      <button
        onClick={onBack}
        className="flex items-center gap-2 text-slate-500 hover:text-slate-700 font-bold mb-4 transition-colors"
      >
        <ArrowLeft className="w-5 h-5" />
        Back to course
      </button>

      {/* Phase toggle */}
      <div className="flex gap-2 p-1 bg-slate-100 rounded-2xl mb-6 max-w-xs">
        <button
          onClick={() => setPhase('learn')}
          className={`flex-1 py-2 rounded-xl font-bold text-sm transition-all ${
            phase === 'learn' ? 'bg-white text-brand-600 shadow-sm' : 'text-slate-500'
          }`}
        >
          Learn
        </button>
        <button
          onClick={() => setPhase('challenge')}
          className={`flex-1 py-2 rounded-xl font-bold text-sm transition-all ${
            phase === 'challenge' ? 'bg-white text-brand-600 shadow-sm' : 'text-slate-500'
          }`}
        >
          Challenge
        </button>
      </div>

      {phase === 'learn' ? (
        <div className="space-y-4 animate-fade-in">
          <div className="card p-6">
            <h1 className="text-2xl font-extrabold text-slate-800 mb-1">{lesson.title}</h1>
            <p className="text-slate-500 font-semibold mb-6">{lesson.description}</p>

            {lesson.content.sections.map((section, idx) => {
              if (section.type === 'text') {
                return (
                  <div key={idx} className="mb-6">
                    <h3 className="font-bold text-slate-700 mb-2 text-lg">{section.title}</h3>
                    <p className="text-slate-600 leading-relaxed">{section.body}</p>
                  </div>
                );
              }
              if (section.type === 'code') {
                return (
                  <div key={idx} className="mb-6">
                    <h3 className="font-bold text-slate-700 mb-2">{section.title}</h3>
                    <div className="rounded-2xl overflow-hidden border border-slate-200">
                      <div className="bg-slate-800 px-4 py-3 overflow-x-auto">
                        <pre className="text-sm text-slate-100 font-mono whitespace-pre">{section.code}</pre>
                      </div>
                      {section.output && (
                        <div className="bg-slate-900 px-4 py-3 border-t border-slate-700">
                          <div className="flex items-center gap-2 text-xs font-bold text-slate-400 mb-1">
                            <Terminal className="w-3 h-3" />
                            OUTPUT
                          </div>
                          <pre className="text-sm text-success-400 font-mono whitespace-pre">{section.output}</pre>
                        </div>
                      )}
                    </div>
                  </div>
                );
              }
              if (section.type === 'tip') {
                return (
                  <div key={idx} className="flex gap-3 p-4 rounded-2xl bg-accent-50 border border-accent-100 mb-6">
                    <Lightbulb className="w-5 h-5 text-accent-500 flex-shrink-0 mt-0.5" />
                    <p className="text-sm text-accent-800 font-semibold">{section.body}</p>
                  </div>
                );
              }
              return null;
            })}

            <button
              onClick={() => setPhase('challenge')}
              className="btn-primary w-full mt-4 flex items-center justify-center gap-2"
            >
              Start Challenge
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      ) : (
        <div className="space-y-4 animate-fade-in">
          {/* Challenge prompt */}
          <div className="card p-6">
            <div className="flex items-center gap-2 mb-3">
              <div
                className="flex items-center justify-center w-8 h-8 rounded-lg text-white font-bold text-sm"
                style={{ backgroundColor: course.color }}
              >
                {course.icon}
              </div>
              <h2 className="font-extrabold text-slate-800">Challenge</h2>
            </div>
            <p className="text-slate-600 font-semibold mb-4">{lesson.challenge.prompt}</p>

            <div className="flex items-center gap-2 text-sm">
              <Star className="w-4 h-4 fill-accent-400 text-accent-400" />
              <span className="font-bold text-slate-500">Earn {lesson.xp_reward} XP</span>
            </div>
          </div>

          {/* Code editor */}
          <div className="card overflow-hidden">
            <div className="flex items-center justify-between px-4 py-2.5 bg-slate-800 border-b border-slate-700">
              <div className="flex items-center gap-2">
                <div className="flex gap-1.5">
                  <div className="w-3 h-3 rounded-full bg-error-400" />
                  <div className="w-3 h-3 rounded-full bg-accent-400" />
                  <div className="w-3 h-3 rounded-full bg-success-400" />
                </div>
                <span className="text-xs font-bold text-slate-400 ml-2 font-mono">
                  {course.language.toLowerCase()}
                </span>
              </div>
              <button
                onClick={resetCode}
                className="flex items-center gap-1 text-xs font-bold text-slate-400 hover:text-slate-200 transition-colors"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Reset
              </button>
            </div>
            <textarea
              ref={textareaRef}
              value={code}
              onChange={(e) => setCode(e.target.value)}
              onKeyDown={handleKeyDown}
              spellCheck={false}
              className="code-editor w-full min-h-[200px] px-4 py-3 bg-slate-900 text-slate-100 font-mono text-sm outline-none resize-y leading-relaxed"
              placeholder="Write your code here..."
            />
          </div>

          {/* Action buttons */}
          <div className="flex gap-3">
            <button
              onClick={runCode}
              disabled={running || submitting}
              className="btn-primary flex-1 flex items-center justify-center gap-2"
            >
              {running || submitting ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  <Play className="w-5 h-5 fill-current" />
                  Run & Check
                </>
              )}
            </button>
            <button
              onClick={() => { setShowHint(!showHint); setHintLevel(0); }}
              className="btn-secondary flex items-center gap-2"
            >
              <Lightbulb className="w-5 h-5" />
              Hint
            </button>
          </div>

          {/* Progressive hints */}
          {showHint && (
            <div className="card p-4 border-accent-200 bg-accent-50 animate-slide-up">
              <div className="flex gap-3">
                <Lightbulb className="w-5 h-5 text-accent-500 flex-shrink-0 mt-0.5" />
                <div className="flex-1">
                  <p className="font-bold text-accent-800 text-sm mb-1">Hint {hintLevel + 1} of {hints.length}</p>
                  <p className="text-sm text-accent-700 font-semibold mb-2">{hints[hintLevel]}</p>
                  {hintLevel < hints.length - 1 && (
                    <button
                      onClick={() => setHintLevel(hintLevel + 1)}
                      className="text-xs font-bold text-accent-600 hover:text-accent-800 transition-colors"
                    >
                      Need another hint? →
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* HTML Preview */}
          {isHtmlCss && preview && (
            <div className="card overflow-hidden animate-slide-up">
              <div className="px-4 py-2.5 bg-slate-800 border-b border-slate-700">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-400">
                  <Eye className="w-3.5 h-3.5" />
                  PREVIEW
                </div>
              </div>
              <div className="p-4 bg-white">
                <iframe
                  srcDoc={preview}
                  className="w-full min-h-[150px] border-0"
                  title="HTML Preview"
                  sandbox="allow-same-origin"
                />
              </div>
            </div>
          )}

          {/* Output */}
          {output && (
            <div className="card overflow-hidden animate-slide-up">
              <div className="px-4 py-2.5 bg-slate-800 border-b border-slate-700">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-400">
                  <Terminal className="w-3.5 h-3.5" />
                  OUTPUT
                </div>
              </div>
              <div className="p-4 bg-slate-900 min-h-[60px]">
                <pre className={`text-sm font-mono whitespace-pre-wrap ${error ? 'text-error-400' : 'text-slate-100'}`}>
                  {output}
                </pre>
              </div>
            </div>
          )}

          {/* Error */}
          {error && (
            <div className="flex items-start gap-2 p-4 rounded-2xl bg-error-50 border border-error-200 animate-shake">
              <X className="w-5 h-5 text-error-500 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-error-700 text-sm">Error</p>
                <p className="text-sm text-error-600 font-mono mt-1">{error}</p>
              </div>
            </div>
          )}

          {/* Success */}
          {passed && !error && (
            <div className="flex items-start gap-2 p-4 rounded-2xl bg-success-50 border border-success-200 animate-slide-up">
              <Check className="w-5 h-5 text-success-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-success-700 text-sm">Correct! Saving your progress...</p>
              </div>
            </div>
          )}

          {/* Show solution after repeated failed attempts */}
          {attempts >= 2 && !passed && !error && (
            <div className="card p-4 border-accent-200 bg-accent-50 animate-slide-up">
              <div className="flex items-start gap-3">
                <Lightbulb className="w-5 h-5 text-accent-500 flex-shrink-0 mt-0.5" />
                <div className="flex-1">
                  <p className="font-bold text-accent-800 text-sm mb-1">Stuck? Here's the solution</p>
                  <p className="text-xs text-accent-700 font-semibold mb-3">
                    You've tried {attempts} times. Reveal the answer to study it, or keep trying on your own.
                  </p>
                  {!showSolution ? (
                    <button
                      onClick={() => setShowSolution(true)}
                      className="px-3 py-1.5 rounded-xl bg-accent-500 text-white text-xs font-bold hover:bg-accent-600 transition-colors"
                    >
                      Reveal Solution
                    </button>
                  ) : (
                    <pre className="text-xs text-accent-800 font-mono whitespace-pre-wrap bg-white/70 rounded-lg p-3 mt-1">
                      {lesson.challenge.solution}
                    </pre>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
