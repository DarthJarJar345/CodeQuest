import { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { Course, Lesson, LessonProgress, Achievement, UserAchievement, PracticeSession as PracticeSessionType } from '../lib/supabase';
import {
  fetchCourses, fetchAllLessons, fetchUserProgress, fetchAchievements,
  fetchUserAchievements, fetchPracticeSessions, getEffectiveStrength,
  computeTodayXp, updateDailyGoal,
} from '../lib/api';
import { Flame, BookOpen, Award, TrendingUp, Zap, Dumbbell, Brain, Target, Check } from 'lucide-react';

export default function ProfileView() {
  const { user, profile, refreshProfile } = useAuth();
  const [courses, setCourses] = useState<Course[]>([]);
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [progress, setProgress] = useState<LessonProgress[]>([]);
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [userAchievements, setUserAchievements] = useState<UserAchievement[]>([]);
  const [practiceSessions, setPracticeSessions] = useState<PracticeSessionType[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    Promise.all([
      fetchCourses(),
      fetchAllLessons(),
      fetchUserProgress(user.id),
      fetchAchievements(),
      fetchUserAchievements(user.id),
      fetchPracticeSessions(user.id),
    ]).then(([c, l, p, a, ua, ps]) => {
      setCourses(c);
      setLessons(l);
      setProgress(p);
      setAchievements(a);
      setUserAchievements(ua);
      setPracticeSessions(ps);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, [user]);

  if (loading || !profile) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-8 h-8 border-4 border-brand-200 border-t-brand-500 rounded-full animate-spin" />
      </div>
    );
  }

  const completedProgress = progress.filter((p) => p.status === 'completed');
  const completedLessonIds = new Set(completedProgress.map((p) => p.lesson_id));
  const completedLessons = completedProgress.length;

  const practiceCount = practiceSessions.length;
  const practiceCorrect = practiceSessions.filter((s) => s.correct).length;
  const practiceAccuracy = practiceCount > 0 ? Math.round((practiceCorrect / practiceCount) * 100) : 0;
  const avgStrength = completedProgress.length > 0
    ? completedProgress.reduce((sum, p) => sum + getEffectiveStrength(p), 0) / completedProgress.length
    : 0;

  const todayXp = computeTodayXp(progress, practiceSessions);
  const dailyGoal = profile.daily_goal ?? 30;
  const goalPct = Math.min(100, Math.round((todayXp / dailyGoal) * 100));
  const goalMet = todayXp >= dailyGoal;

  // Per-course stats
  const courseStats = courses.map((course) => {
    const courseLessons = lessons.filter((l) => l.course_id === course.id);
    const completed = courseLessons.filter((l) => completedLessonIds.has(l.id)).length;
    return { course, completed, total: courseLessons.length };
  });

  const unlockedAchievementIds = new Set(userAchievements.map((ua) => ua.achievement_id));
  const unlockedAchievements = achievements.filter((a) => unlockedAchievementIds.has(a.id));

  // Calculate level from XP (every 100 XP = 1 level)
  const level = Math.floor(profile.total_xp / 100) + 1;
  const xpInLevel = profile.total_xp % 100;
  const xpForNextLevel = 100;
  const levelPct = (xpInLevel / xpForNextLevel) * 100;

  const stats = [
    { icon: Flame, label: 'Current Streak', value: `${profile.current_streak} days`, color: 'text-accent-500', bg: 'bg-accent-50' },
    { icon: TrendingUp, label: 'Longest Streak', value: `${profile.longest_streak} days`, color: 'text-success-600', bg: 'bg-success-50' },
    { icon: BookOpen, label: 'Lessons Done', value: `${completedLessons}`, color: 'text-brand-500', bg: 'bg-brand-50' },
    { icon: Dumbbell, label: 'Practice Sessions', value: `${practiceCount}`, color: 'text-purple-500', bg: 'bg-purple-50' },
    { icon: Brain, label: 'Avg Strength', value: `${Math.round(avgStrength * 100)}%`, color: 'text-brand-600', bg: 'bg-brand-50' },
    { icon: Zap, label: 'Practice Accuracy', value: `${practiceAccuracy}%`, color: 'text-accent-600', bg: 'bg-accent-50' },
    { icon: Award, label: 'Achievements', value: `${unlockedAchievements.length}/${achievements.length}`, color: 'text-success-600', bg: 'bg-success-50' },
  ];

  return (
    <div className="animate-fade-in">
      {/* Profile header */}
      <div className="card p-6 mb-6">
        <div className="flex items-center gap-4 mb-6">
          <div className="flex items-center justify-center w-20 h-20 rounded-3xl bg-gradient-to-br from-brand-400 to-brand-600 text-white text-3xl font-extrabold shadow-lg shadow-brand-500/30">
            {profile.username.charAt(0).toUpperCase()}
          </div>
          <div>
            <h1 className="text-2xl font-extrabold text-slate-800">{profile.username}</h1>
            <p className="text-slate-400 font-semibold text-sm">{user?.email}</p>
          </div>
        </div>

        {/* Level + XP bar */}
        <div className="mb-4">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <div className="flex items-center justify-center w-8 h-8 rounded-xl bg-gradient-to-br from-accent-400 to-accent-600 text-white font-extrabold text-sm shadow-md">
                {level}
              </div>
              <span className="font-bold text-slate-700">Level {level}</span>
            </div>
            <span className="text-sm font-bold text-slate-400">
              {xpInLevel} / {xpForNextLevel} XP
            </span>
          </div>
          <div className="h-3 rounded-full bg-slate-100 overflow-hidden">
            <div
              className="h-full rounded-full bg-gradient-to-r from-accent-400 to-accent-600 transition-all duration-500"
              style={{ width: `${levelPct}%` }}
            />
          </div>
        </div>

        {/* Total XP */}
        <div className="flex items-center gap-2 p-3 rounded-2xl bg-brand-50 border border-brand-100">
          <Zap className="w-5 h-5 text-brand-500" />
          <span className="font-extrabold text-brand-700">{profile.total_xp} Total XP</span>
        </div>
      </div>

      {/* Daily goal */}
      <DailyGoalCard
        todayXp={todayXp}
        dailyGoal={dailyGoal}
        goalPct={goalPct}
        goalMet={goalMet}
        userId={user?.id ?? ''}
        onGoalChanged={() => refreshProfile()}
      />

      {/* Stats grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-6">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.label} className="card p-4">
              <div className={`flex items-center justify-center w-10 h-10 rounded-xl ${stat.bg} mb-2`}>
                <Icon className={`w-5 h-5 ${stat.color}`} />
              </div>
              <p className="text-xs font-bold text-slate-400 uppercase tracking-wide">{stat.label}</p>
              <p className="text-lg font-extrabold text-slate-800">{stat.value}</p>
            </div>
          );
        })}
      </div>

      {/* Course progress */}
      <div className="card p-6 mb-6">
        <h2 className="font-extrabold text-slate-800 mb-4">Course Progress</h2>
        <div className="space-y-4">
          {courseStats.map(({ course, completed, total }) => {
            const pct = total > 0 ? (completed / total) * 100 : 0;
            return (
              <div key={course.id}>
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-2">
                    <span className="text-xl">{course.icon}</span>
                    <span className="font-bold text-slate-700 text-sm">{course.title}</span>
                  </div>
                  <span className="text-xs font-bold text-slate-400">{completed}/{total}</span>
                </div>
                <div className="h-2.5 rounded-full bg-slate-100 overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{ width: `${pct}%`, backgroundColor: course.color }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Recent achievements */}
      {unlockedAchievements.length > 0 && (
        <div className="card p-6">
          <h2 className="font-extrabold text-slate-800 mb-4">Unlocked Achievements</h2>
          <div className="flex flex-wrap gap-2">
            {unlockedAchievements.map((a) => (
              <div
                key={a.id}
                className="flex items-center gap-2 px-3 py-2 rounded-xl bg-brand-50 border border-brand-100"
                title={a.description}
              >
                <span className="text-lg">{a.icon}</span>
                <span className="font-bold text-brand-700 text-sm">{a.title}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

const GOAL_OPTIONS = [10, 30, 50, 100];

function DailyGoalCard({
  todayXp, dailyGoal, goalPct, goalMet, userId, onGoalChanged,
}: {
  todayXp: number;
  dailyGoal: number;
  goalPct: number;
  goalMet: boolean;
  userId: string;
  onGoalChanged: () => void;
}) {
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);

  const pickGoal = async (goal: number) => {
    setSaving(true);
    try {
      await updateDailyGoal(userId, goal);
      onGoalChanged();
      setEditing(false);
    } catch (err) {
      console.error('Failed to update daily goal:', err);
    }
    setSaving(false);
  };

  return (
    <div className="card p-6 mb-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Target className="w-5 h-5 text-accent-500" />
          <h2 className="font-extrabold text-slate-800">Daily Goal</h2>
        </div>
        <button
          onClick={() => setEditing(!editing)}
          className="text-xs font-bold text-brand-500 hover:text-brand-600 transition-colors"
        >
          {editing ? 'Cancel' : 'Edit'}
        </button>
      </div>

      <div className="flex items-center gap-4">
        <div className="relative w-20 h-20 flex-shrink-0">
          <svg className="w-20 h-20 -rotate-90" viewBox="0 0 36 36">
            <circle cx="18" cy="18" r="15.5" fill="none" stroke="#e2e8f0" strokeWidth="3.5" />
            <circle
              cx="18" cy="18" r="15.5" fill="none"
              stroke={goalMet ? '#22c55e' : '#3399ff'}
              strokeWidth="3.5"
              strokeDasharray={`${goalPct} 100`}
              strokeLinecap="round"
              className="transition-all duration-500"
            />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center">
            {goalMet ? (
              <Check className="w-8 h-8 text-success-500" strokeWidth={3} />
            ) : (
              <div className="text-center">
                <div className="text-sm font-extrabold text-slate-700 leading-none">{goalPct}%</div>
              </div>
            )}
          </div>
        </div>
        <div className="flex-1">
          <p className="text-sm font-bold text-slate-700">
            {todayXp} / {dailyGoal} XP today
          </p>
          <p className="text-xs text-slate-400 font-semibold mt-0.5">
            {goalMet
              ? 'Daily goal reached! Streak preserved.'
              : `${dailyGoal - todayXp} XP left to reach your goal.`}
          </p>
        </div>
      </div>

      {editing && (
        <div className="mt-4 pt-4 border-t border-slate-100 animate-slide-up">
          <p className="text-xs font-bold text-slate-500 uppercase tracking-wide mb-2">
            Set your daily goal
          </p>
          <div className="flex gap-2">
            {GOAL_OPTIONS.map((opt) => (
              <button
                key={opt}
                onClick={() => pickGoal(opt)}
                disabled={saving}
                className={`flex-1 py-2.5 rounded-xl font-bold text-sm transition-all ${
                  opt === dailyGoal
                    ? 'bg-brand-500 text-white shadow-md'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                } disabled:opacity-50`}
              >
                {opt} XP
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
