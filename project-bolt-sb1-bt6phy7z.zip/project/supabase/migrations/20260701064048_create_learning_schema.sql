/*
# Create gamified coding education schema

## Overview
Creates the full database schema for a Duolingo-style coding education platform.
Users sign up, progress through courses (Python, JavaScript, HTML/CSS, SQL),
complete bite-sized lessons and interactive code challenges, earn XP, maintain
streaks, and unlock achievements.

## New Tables

### profiles
- `id` (uuid, PK, references auth.users) — one row per user
- `username` (text, unique) — display name
- `total_xp` (int, default 0) — cumulative XP across all courses
- `current_streak` (int, default 0) — consecutive days with activity
- `longest_streak` (int, default 0) — best streak ever
- `last_activity_date` (date, nullable) — used for streak calculation
- `created_at` (timestamptz)

### courses
- `id` (uuid, PK)
- `slug` (text, unique) — e.g. "python", "javascript"
- `title` (text)
- `description` (text)
- `language` (text) — programming language
- `icon` (text) — emoji or icon name
- `color` (text) — theme color for the course
- `difficulty_order` (int) — display order
- `created_at` (timestamptz)

### lessons
- `id` (uuid, PK)
- `course_id` (uuid, FK → courses)
- `title` (text)
- `description` (text)
- `content` (jsonb) — lesson content: explanation text, code examples, etc.
- `challenge` (jsonb) — the interactive challenge: type, prompt, starter code, solution, test cases
- `xp_reward` (int, default 10)
- `order_index` (int) — order within course
- `created_at` (timestamptz)

### lesson_progress
- `id` (uuid, PK)
- `user_id` (uuid, FK → auth.users, default auth.uid())
- `lesson_id` (uuid, FK → lessons)
- `status` (text: 'in_progress', 'completed')
- `xp_earned` (int, default 0)
- `completed_at` (timestamptz, nullable)
- `created_at` (timestamptz)
- Unique constraint on (user_id, lesson_id)

### achievements
- `id` (uuid, PK)
- `slug` (text, unique)
- `title` (text)
- `description` (text)
- `icon` (text)
- `xp_bonus` (int, default 0)
- `created_at` (timestamptz)

### user_achievements
- `id` (uuid, PK)
- `user_id` (uuid, FK → auth.users, default auth.uid())
- `achievement_id` (uuid, FK → achievements)
- `unlocked_at` (timestamptz)
- Unique constraint on (user_id, achievement_id)

## Security
- RLS enabled on all tables.
- profiles, lesson_progress, user_achievements: owner-scoped (auth.uid() = user_id).
- courses, lessons, achievements: public read (TO anon, authenticated) so unauthenticated users can browse.
- lesson_progress and user_achievements allow owner insert/update only.
*/

-- Profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username text UNIQUE NOT NULL,
  total_xp int NOT NULL DEFAULT 0,
  current_streak int NOT NULL DEFAULT 0,
  longest_streak int NOT NULL DEFAULT 0,
  last_activity_date date,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_profile" ON profiles;
CREATE POLICY "select_own_profile" ON profiles FOR SELECT
  TO authenticated USING (auth.uid() = id);

DROP POLICY IF EXISTS "insert_own_profile" ON profiles;
CREATE POLICY "insert_own_profile" ON profiles FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "update_own_profile" ON profiles;
CREATE POLICY "update_own_profile" ON profiles FOR UPDATE
  TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

-- Courses table (public read)
CREATE TABLE IF NOT EXISTS courses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text UNIQUE NOT NULL,
  title text NOT NULL,
  description text NOT NULL,
  language text NOT NULL,
  icon text NOT NULL,
  color text NOT NULL,
  difficulty_order int NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE courses ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "public_read_courses" ON courses;
CREATE POLICY "public_read_courses" ON courses FOR SELECT
  TO anon, authenticated USING (true);

-- Lessons table (public read)
CREATE TABLE IF NOT EXISTS lessons (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id uuid NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text NOT NULL,
  content jsonb NOT NULL DEFAULT '{}',
  challenge jsonb NOT NULL DEFAULT '{}',
  xp_reward int NOT NULL DEFAULT 10,
  order_index int NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE lessons ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "public_read_lessons" ON lessons;
CREATE POLICY "public_read_lessons" ON lessons FOR SELECT
  TO anon, authenticated USING (true);

-- Lesson progress (owner-scoped)
CREATE TABLE IF NOT EXISTS lesson_progress (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  lesson_id uuid NOT NULL REFERENCES lessons(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'in_progress' CHECK (status IN ('in_progress', 'completed')),
  xp_earned int NOT NULL DEFAULT 0,
  completed_at timestamptz,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, lesson_id)
);
ALTER TABLE lesson_progress ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_progress" ON lesson_progress;
CREATE POLICY "select_own_progress" ON lesson_progress FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_progress" ON lesson_progress;
CREATE POLICY "insert_own_progress" ON lesson_progress FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_progress" ON lesson_progress;
CREATE POLICY "update_own_progress" ON lesson_progress FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_progress" ON lesson_progress;
CREATE POLICY "delete_own_progress" ON lesson_progress FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Achievements (public read)
CREATE TABLE IF NOT EXISTS achievements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text UNIQUE NOT NULL,
  title text NOT NULL,
  description text NOT NULL,
  icon text NOT NULL,
  xp_bonus int NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE achievements ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "public_read_achievements" ON achievements;
CREATE POLICY "public_read_achievements" ON achievements FOR SELECT
  TO anon, authenticated USING (true);

-- User achievements (owner-scoped)
CREATE TABLE IF NOT EXISTS user_achievements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  achievement_id uuid NOT NULL REFERENCES achievements(id) ON DELETE CASCADE,
  unlocked_at timestamptz DEFAULT now(),
  UNIQUE(user_id, achievement_id)
);
ALTER TABLE user_achievements ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_user_achievements" ON user_achievements;
CREATE POLICY "select_own_user_achievements" ON user_achievements FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_user_achievements" ON user_achievements;
CREATE POLICY "insert_own_user_achievements" ON user_achievements FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_user_achievements" ON user_achievements;
CREATE POLICY "delete_own_user_achievements" ON user_achievements FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_lessons_course_id ON lessons(course_id);
CREATE INDEX IF NOT EXISTS idx_lesson_progress_user_id ON lesson_progress(user_id);
CREATE INDEX IF NOT EXISTS idx_user_achievements_user_id ON user_achievements(user_id);