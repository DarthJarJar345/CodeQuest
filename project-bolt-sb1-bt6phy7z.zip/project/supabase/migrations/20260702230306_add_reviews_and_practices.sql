/*
# Add Reviews and Practices (Duolingo-style)

## Overview
Adds a spaced-repetition-style review system on top of the existing lesson
progress. Each completed lesson now has a "strength" score (0.0–1.0) that
decays over time. Users can launch focused practice sessions that re-quiz
them on completed lessons to restore strength, earn a smaller XP reward,
and keep their skills sharp — exactly like Duolingo's "Practice" / "Weak
Skills" features.

## Modified Tables

### lesson_progress (added columns)
- `strength` (real, default 1.0) — current mastery score 0.0–1.0. Newly
  completed lessons start at full strength; the score decays over time and
  is restored (and can exceed 1.0 up to a cap) by successful reviews.
- `last_reviewed_at` (timestamptz, nullable) — when the user last practiced
  this lesson. Used together with `completed_at` to compute decay.
- `review_count` (int, default 0) — total number of practice attempts on
  this lesson.
- `times_correct` (int, default 0) — practice attempts the user passed.
- `times_incorrect` (int, default 0) — practice attempts the user failed.

The existing `status`, `xp_earned`, and `completed_at` columns are
unchanged. No data is lost; existing rows pick up the column defaults.

## New Tables

### practice_sessions
- `id` (uuid, PK)
- `user_id` (uuid, FK → auth.users, default auth.uid()) — owner
- `lesson_id` (uuid, FK → lessons) — the lesson that was practiced
- `correct` (boolean, not null) — whether the practice attempt passed
- `xp_earned` (int, default 0) — XP awarded for this attempt (smaller than
  the lesson's full reward; 0 on failure)
- `completed_at` (timestamptz, default now())
- `created_at` (timestamptz, default now())

This is an append-only log of every practice attempt, used for stats,
achievements, and the practice history view.

## Security
- RLS already enabled on `lesson_progress`; the existing owner-scoped
  SELECT/INSERT/UPDATE/DELETE policies cover the new columns automatically
  (policies apply to the row, not individual columns).
- RLS enabled on the new `practice_sessions` table with four owner-scoped
  policies (SELECT/INSERT/UPDATE/DELETE), `TO authenticated`, using
  `auth.uid() = user_id`. The `user_id` column defaults to `auth.uid()` so
  client inserts that omit `user_id` still satisfy the INSERT WITH CHECK.
- No public/anon access: practice data is private to each user.

## Important Notes
1. Strength decay is computed in the frontend at read time from
   `last_reviewed_at` (or `completed_at` for never-reviewed lessons) so the
   schema stays simple and the decay curve can be tuned without a
   migration.
2. Practice XP is intentionally smaller than lesson XP (the frontend passes
   a reduced reward) so users can't farm XP by re-practicing the same
   lesson forever — and `completeLesson` already guards against awarding
   full XP twice for the same lesson.
3. The new `practice_sessions` table is append-only from the client's
   perspective; UPDATE/DELETE policies exist only for completeness and
   potential future admin tooling.
*/

-- ─── Extend lesson_progress with review tracking ─────────────────────────

ALTER TABLE lesson_progress
  ADD COLUMN IF NOT EXISTS strength real NOT NULL DEFAULT 1.0
    CHECK (strength >= 0 AND strength <= 2.0);

ALTER TABLE lesson_progress
  ADD COLUMN IF NOT EXISTS last_reviewed_at timestamptz;

ALTER TABLE lesson_progress
  ADD COLUMN IF NOT EXISTS review_count int NOT NULL DEFAULT 0;

ALTER TABLE lesson_progress
  ADD COLUMN IF NOT EXISTS times_correct int NOT NULL DEFAULT 0;

ALTER TABLE lesson_progress
  ADD COLUMN IF NOT EXISTS times_incorrect int NOT NULL DEFAULT 0;

CREATE INDEX IF NOT EXISTS idx_lesson_progress_last_reviewed
  ON lesson_progress(last_reviewed_at);

-- ─── practice_sessions table ─────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS practice_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  lesson_id uuid NOT NULL REFERENCES lessons(id) ON DELETE CASCADE,
  correct boolean NOT NULL,
  xp_earned int NOT NULL DEFAULT 0,
  completed_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE practice_sessions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_practice_sessions" ON practice_sessions;
CREATE POLICY "select_own_practice_sessions" ON practice_sessions FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_practice_sessions" ON practice_sessions;
CREATE POLICY "insert_own_practice_sessions" ON practice_sessions FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_practice_sessions" ON practice_sessions;
CREATE POLICY "update_own_practice_sessions" ON practice_sessions FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_practice_sessions" ON practice_sessions;
CREATE POLICY "delete_own_practice_sessions" ON practice_sessions FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_practice_sessions_user_id
  ON practice_sessions(user_id);

CREATE INDEX IF NOT EXISTS idx_practice_sessions_completed_at
  ON practice_sessions(completed_at DESC);

-- ─── Practice-related achievements ────────────────────────────────────────
-- Insert with ON CONFLICT so re-running the migration is safe.

INSERT INTO achievements (slug, title, description, icon, xp_bonus) VALUES
  ('practice_10', 'Practice Makes Perfect', 'Complete 10 practice sessions', '🏋️', 50),
  ('practice_50', 'Practice Pro', 'Complete 50 practice sessions', '💪', 150),
  ('sharp_shooter', 'Sharp Shooter', 'Get 10 practice sessions correct in a row', '🎯', 100),
  ('review_master', 'Review Master', 'Restore 5 lessons to full strength', '✨', 100)
ON CONFLICT (slug) DO NOTHING;