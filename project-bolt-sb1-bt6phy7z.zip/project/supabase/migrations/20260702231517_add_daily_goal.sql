/*
# Add daily goal tracking

## Overview
Adds a daily XP goal to each user's profile so they can track their daily
learning target — like Duolingo's daily goal. The goal is user-configurable
(defaults to 30 XP), and the frontend compares today's XP earnings against
the goal to show progress.

## Modified Tables

### profiles (added column)
- `daily_goal` (int, default 30) — the user's daily XP target. The frontend
  computes today's earned XP from `lesson_progress.xp_earned` (for lessons
  completed today) plus `practice_sessions.xp_earned` (for practice sessions
  completed today) and compares against this goal.

No new tables. No data is lost; existing rows pick up the default of 30.

## Security
- RLS already enabled on `profiles`; the existing owner-scoped SELECT /
  INSERT / UPDATE policies cover the new column automatically (policies
  apply to the row, not individual columns).
- No new policies needed.

## Important Notes
1. The daily goal is intentionally a profile-level setting (not a separate
  table) to keep the schema simple and avoid extra joins.
2. Today's XP is computed in the frontend from existing timestamped rows;
  no denormalized counter is needed.
*/

ALTER TABLE profiles
  ADD COLUMN IF NOT EXISTS daily_goal int NOT NULL DEFAULT 30
    CHECK (daily_goal >= 10 AND daily_goal <= 200);